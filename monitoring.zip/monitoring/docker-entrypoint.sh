#!/bin/bash
function main() {
  sleep 20
  PLATFORM=$1
  ENVIRONMENT=$2
  set -x
  echo "Starting cron service"
  service cron start

  sleep 5

  echo "Executing job monitoring task"
  /usr/bin/python3.9 /apps/main.py "$PLATFORM" "$ENVIRONMENT"  && tail -F /dev/null
}


main "$@"