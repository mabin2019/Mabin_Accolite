import os
from crontab import CronTab
from monitoring.util import helpers

logger = helpers.initialize_logger()


def setup_cron(monitoring_task_name, script, script_interpreter, cron_interval, *args):
    """
    Creates cron task with the configured duration to execute configured script

    Arguments:
        cron_interval: Cron expression to schedule the task
        monitoring_task_name: Monitoring task name for which cron is being set up
        script: Script to be executed at cron intervals
        script_interpreter: Script Interpreter
        *args: Arguments to be passed to script

    """

    dir_path = os.path.dirname(os.path.realpath(__file__))
    jobs_monitor_script_filename = os.path.join(dir_path, script)

    script_args = ' '.join(args)
    cron_command_tuple = (script_interpreter, jobs_monitor_script_filename, script_args)
    cron_command = ' '.join(cron_command_tuple)

    cron = CronTab(user=True)

    # Remove cron task with comment before adding a new task
    cron.remove_all(comment=monitoring_task_name)
    logger.info("Executing cron tab for %s" % monitoring_task_name)
    job = cron.new(command=cron_command, comment=monitoring_task_name)
    cron_duration_unit = cron_interval[-1]
    cron_duration = cron_interval[:-1:]
    if cron_duration_unit == 'H':
        job.hour.every(cron_duration)
        job.minute.on(1)
    elif cron_duration_unit == 'M':
        job.minute.every(cron_duration)
    cron.write()
