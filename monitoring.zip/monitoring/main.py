from monitoring.util import helpers
from monitoring import setup_monitoring_cron
import os
import configparser
import sys

if __name__ == '__main__':
    """Main script to start monitoring tasks driven by configuration file.

        Each section in the configuration file contains details required to
        set up monitoring task(script file name, cron duration, etc.)
        Iterates through the list of monitoring tasks from config file and sets up the cron task.
        """

    n = len(sys.argv)
    if n < 3:
        print("Platform and Environment state not provided")
        sys.exit(1)
    platform = sys.argv[1]
    env_state = sys.argv[2]

    # Initializing helper class with platform and env_state
    helper_obj = helpers.Helper(platform=platform, env_state=env_state)
    logger = helpers.initialize_logger()

    dir_path = os.path.dirname(os.path.realpath(__file__))
    conf = configparser.ConfigParser()
    conf.read(dir_path + "/monitoring/configs/" + platform + "/cron_setup.ini")

    logger.info("Creating cron for monitoring tasks")
    for cron_task in conf.sections():
        logger.info("Invoking setup_cron function for %s task" % cron_task)
        script_to_be_executed = conf.get(cron_task, 'SCRIPT_TO_BE_EXECUTED')
        cron_duration = conf.get(cron_task, 'CRON_INTERVAL')
        script_interpreter = conf.get(cron_task, 'SCRIPT_INTERPRETER')
        if conf.has_option(cron_task, 'SCRIPT_ARGS'):
            setup_monitoring_cron.setup_cron(cron_task, script_to_be_executed, script_interpreter, cron_duration,
                                             conf.get(cron_task, 'SCRIPT_ARGS'), platform, env_state)
        else:
            setup_monitoring_cron.setup_cron(cron_task, script_to_be_executed, script_interpreter, cron_duration,
                                             platform, env_state)