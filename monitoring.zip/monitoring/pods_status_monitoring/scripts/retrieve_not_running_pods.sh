#!/bin/bash
function main() {
  DIRNAME=$(dirname "$0")
  ENVIRONMENT_STATE=$2
  >${DIRNAME}/pods_list.txt
  pods_list="${DIRNAME}/pods_list.txt"

  ignore_list="${DIRNAME}/pods_to_be_ignored.txt"

  if [ $(/usr/local/bin/kubectl --kubeconfig $1 get pods | wc -l) -eq 0 ]; then
    echo "The deployer token entered is not proper or no pod is started. Please check again."
    exit
  fi
  for i in $(/usr/local/bin/kubectl --kubeconfig $1 get deployments | grep -v 'deploymentpod' | awk '{print $1}' | grep -v NAME); do
    if [[ "$i" == *"deploy"* ]]; then
      conf=1
    else
      conf=$(/usr/local/bin/kubectl --kubeconfig $1 get deployments $i -o yaml | grep replicas | head -1 | tr -d '"' | awk -F 'replicas:' '{print $2}' | cut -d',' -f1)
    fi
    actual=$(/usr/local/bin/kubectl --kubeconfig $1 get pods | grep $i | grep Running | wc -l)
    if [ $conf -ne $actual ]; then
      echo "$i" >>${DIRNAME}/pods_list.txt
    fi
  done
  for i in $(/usr/local/bin/kubectl --kubeconfig $1 get sts | awk '{print $1}' | grep -v NAME); do
    conf=$(/usr/local/bin/kubectl --kubeconfig $1 get sts $i -o yaml | grep replicas | head -1 | tr -d '"' | awk -F 'replicas:' '{print $2}' | cut -d',' -f1)
    c=0
    while [ $c -lt $conf ]; do
      if [ $(/usr/local/bin/kubectl --kubeconfig $1 get pods | grep $i-$c | grep Running | wc -l) -eq 0 ]; then
        echo "${i}-${c}" >>${DIRNAME}/pods_list.txt
      fi
      c=$((c + 1))
    done
  done

  if [[ "$ENVIRONMENT_STATE" -eq "INACTIVE" ]]; then
    list=$(grep -v -f $ignore_list $pods_list | tr '\n' ' ')
    echo "$list"
  else
    list=$(cat $pods_list | tr '\n' ' ')
    echo "$list"
  fi
}

main "$@"