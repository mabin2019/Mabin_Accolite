import json
import os
import subprocess
import sys
import uuid
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from monitoring.util import helpers
from monitoring.util.helpers import Helper

logger = helpers.initialize_logger()


def publish_pod_status_message(env) -> None:
    """
    Publish list of pods which are not running message to Kafka Producer

    """
    pods_status_response = prepare_pods_list(env)

    pod_status = {'pod_names': pods_status_response.split(' ')} if pods_status_response != '' else {}

    timestamp = datetime.now()
    alert_id = str(uuid.uuid1())
    logger.info("List of pods not running %s" % pod_status)
    alert_flag = helper.get_boolean_property('POD_MONITORING', 'ALERT_REQUIRED')
    environment = helper.get_property('DEFAULT', 'ENVIRONMENT')
    message = {"notificationChannel": "SLACK", "type": "pods-monitor-alert",
               "data_set": pod_status, "alertId": alert_id, "environment": environment,
               "timestamp": str(timestamp), "is_alert": alert_flag}
    json_message = json.dumps(message)
    print(json_message)
    helpers.post_alert_message(helper.get_property('DEFAULT', 'MESSAGE_POST_URL'), json_message)


def prepare_pods_list(env) -> str:
    """
    Execute shell script to prepare list of pods which are not running

    Returns: Shell script decoded response
    """
    dir_path = os.path.dirname(os.path.realpath(__file__))
    pods_list_script_file = os.path.join(dir_path, 'scripts/retrieve_not_running_pods.sh')

    deployer_token_path = helper.get_property('DEFAULT', 'DEPLOYER_TOKEN_PATH')

    pods_list_script_response = subprocess.Popen(['/bin/bash', pods_list_script_file, deployer_token_path, env],
                                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    pods_list = pods_list_script_response.stdout.read().strip().decode("utf-8")
    logger.info("Pods not running :: %s " % pods_list)

    return pods_list


if __name__ == '__main__':
    n = len(sys.argv)
    if n < 3:
        print("Platform and Environment state not provided")
        sys.exit(1)

    helper = Helper(sys.argv[1], sys.argv[2])
    logger.info("Preparing pod status list")
    publish_pod_status_message(sys.argv[2])
