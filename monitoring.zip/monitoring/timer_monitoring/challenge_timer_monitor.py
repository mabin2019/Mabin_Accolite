import datetime
import json
import os
import sys
import uuid

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from couchbase.cluster import Cluster, ClusterOptions
from couchbase_core.cluster import PasswordAuthenticator

from monitoring.util import helpers

logger = helpers.initialize_logger()


def extract_business_metrics():
    logger.info("Connecting to couchbase cluster to fetch expired timers")
    cb_host = 'couchbase://' + conf.get('DEFAULT', 'CB_HOST') + ':8091'
    cb_username = conf.get('DEFAULT', 'CB_USERNAME')
    cb_password = conf.get('DEFAULT', 'CB_PASSWORD')
    cluster = Cluster(cb_host,
                      ClusterOptions(PasswordAuthenticator(cb_username, cb_password)))

    current_utc = int(datetime.datetime.utcnow().strftime("%s")) * 1000

    logger.info("Current UTC in epoch {current_utc}")

    region_list = conf.get('TIMER_MONITORING', 'REGIONS_TO_BE_MONITORED').split(',')
    expired_timer_ids_list = []
    for region in region_list:
        row_iter = cluster.query("SELECT nextFireTime as nextFireTime FROM {} WHERE type_='Timer' and timerId like "
                                 "'Challenge::Cron::%' "
                                 "and nextFireTime < {}".format('data_' + region, current_utc))
        for row in row_iter:
            timer_ids = {}
            logger.info(row)
            timer_ids['region'] = region
            next_fire_time = row.get('nextFireTime') / 1000.0
            next_fire_timestamp = datetime.datetime.fromtimestamp(next_fire_time).strftime('%Y-%m-%d %H:%M:%S')
            timer_ids['nextFireTime'] = next_fire_timestamp
            expired_timer_ids_list.append(timer_ids)
    logger.info(expired_timer_ids_list)

    timestamp = datetime.datetime.now()
    alert_id = str(uuid.uuid1())
    alert_flag = helper.get_boolean_property('TIMER_MONITORING', 'ALERT_REQUIRED')

    expired_timers = {'expired_timer': expired_timer_ids_list} if expired_timer_ids_list else {}

    environment = helper.get_property('DEFAULT', 'ENVIRONMENT')
    message = {"notificationChannel": "SLACK", "type": "expired-timer-alert",
               "data_set": expired_timers, "alertId": alert_id, "environment": environment,
               "timestamp": str(timestamp), "is_alert": alert_flag}
    json_message = json.dumps(message)
    logger.info(json_message)
    helpers.post_alert_message(helper.get_property('DEFAULT', 'MESSAGE_POST_URL'), json_message)


if __name__ == '__main__':
    n = len(sys.argv)
    if n < 3:
        logger.warning("Platform and Environment state not provided")
        sys.exit(1)

    helper = helpers.get_instance(sys.argv[1], sys.argv[2])
    conf = helper.config

    if sys.argv[2] == 'ACTIVE':
        logger.info("Checking challenge fire time")
        extract_business_metrics()

