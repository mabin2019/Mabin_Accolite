#!/usr/bin/bash
function main() {
  if [ $# -ne 1 ]; then
    echo "Please enter deployer token with absolute path as argument. Exiting...."
    exit
  fi
  DEPLOYER_TOKEN=$1
  ROUTER_SERVICE_NAME='router'
  SUPERVISORS_ENDPOINT='druid/indexer/v1/supervisor'

  ROUTER_HOST=$(/usr/local/bin/kubectl --kubeconfig $DEPLOYER_TOKEN get ingress pulse-ingress -o json | /usr/bin/jq -r '.spec.rules[] | select(.http.paths[].backend.serviceName == "router")' | /usr/bin/jq -r '.host')

  DRUID_SUPERVISORS_RESPONSE=$(curl -ks "https://"$ROUTER_HOST/$SUPERVISORS_ENDPOINT)

  if [ $(echo "$DRUID_SUPERVISORS_RESPONSE" | grep error | wc -l) -ne 0 ]; then
    echo "Error response while getting druid supervisor list"
    exit
  fi
  DRUID_SUPERVISORS_LIST=$(echo $DRUID_SUPERVISORS_RESPONSE | /usr/bin/jq -r '.[]')
  UNHEALTHY_SUPERVISOR_LIST=()
  for DRUID_SUPERVISOR in $DRUID_SUPERVISORS_LIST; do
    SUPERVISOR_HEALTH_STATUS=$(curl -ks "https://"$ROUTER_HOST/$SUPERVISORS_ENDPOINT/$DRUID_SUPERVISOR/status | /usr/bin/jq -r '.payload.state')

    if [[ -z "$SUPERVISOR_HEALTH_STATUS" ]] || [[ "$SUPERVISOR_HEALTH_STATUS" != RUNNING ]]; then
      echo "${DRUID_SUPERVISOR##*_}:$SUPERVISOR_HEALTH_STATUS"
    fi

  done

}

main "$@"
