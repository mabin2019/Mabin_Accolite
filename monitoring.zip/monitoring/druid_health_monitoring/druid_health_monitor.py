import json
import os
import subprocess
import sys
import uuid
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from monitoring.util import helpers
from monitoring.util.helpers import Helper

logger = helpers.initialize_logger()


def publish_druid_health_message() -> None:
    """
    Publish list of unhealthy druid supervisors to Kafka Producer

    """
    druid_health_response = check_druid_health()
    if druid_health_response != 'Error response while getting druid supervisor list':
        unhealthy_supervisor_list = []
        if druid_health_response != '':
            for supervisor_health in druid_health_response.split('\n'):
                supervisor_name = supervisor_health.split(":")[0]
                supervisor_status = supervisor_health.split(":")[1]
                unhealthy_supervisor_list.append(
                    {"name": supervisor_name, "status": supervisor_status})

        druid_health_data = {'supervisor_health': unhealthy_supervisor_list} if unhealthy_supervisor_list else {}
        logger.info(f"Unhealthy druid supervisors {druid_health_data}")
    else:
        druid_health_data = druid_health_response
    timestamp = datetime.now()
    alert_id = str(uuid.uuid1())
    alert_flag = helper.get_boolean_property('DRUID_HEALTH_MONITORING', 'ALERT_REQUIRED')
    environment = helper.get_property('DEFAULT', 'ENVIRONMENT')
    message = {"notificationChannel": "SLACK", "type": "druid-health-alert",
               "data_set": druid_health_data, "alertId": alert_id, "environment": environment,
               "timestamp": str(timestamp), "is_alert": alert_flag}
    json_message = json.dumps(message)
    helpers.post_alert_message(helper.get_property('DEFAULT', 'MESSAGE_POST_URL'), json_message)


def check_druid_health() -> str:
    """
    Execute shell script to get druid supervisor status

    Returns: Shell script decoded response
    """
    dir_path = os.path.dirname(os.path.realpath(__file__))
    druid_health_script_path = os.path.join(dir_path, 'scripts/check_druid_supervisor_health.sh')

    deployer_token_path = helper.get_property('DEFAULT', 'DEPLOYER_TOKEN_PATH')

    druid_health_response = subprocess.Popen(['/bin/bash', druid_health_script_path, deployer_token_path],
                                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    druid_unhealthy_supervisors = druid_health_response.stdout.read().strip().decode("utf-8")
    logger.info(f"Unhealthy druid supervisors :: {druid_unhealthy_supervisors}")

    return druid_unhealthy_supervisors


if __name__ == '__main__':
    n = len(sys.argv)
    if n < 3:
        logger.warning("Platform and Environment state not provided")
        sys.exit(1)
    helper = Helper(sys.argv[1], sys.argv[2])

    if sys.argv[2] == 'ACTIVE':
        logger.info("Checking health status of druid supervisors")
        publish_druid_health_message()
