import json
import os
import subprocess
import sys
import uuid
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from monitoring.util import helpers
from monitoring.util.helpers import Helper


logger = helpers.initialize_logger()


def publish_zknode_count():
    """
    Publish zk node count for zookeeper instances

    """
    zknode_count = execute_zknode_count_script()
    if zknode_count:
        timestamp = datetime.now()
        alert_id = str(uuid.uuid1())

        zknode_count_list = []
        for zknode in zknode_count.split(" "):
            zknode_count_list.append({'zk_pod_name': zknode.split(":")[0], 'zknode_count': zknode.split(":")[1]})

        zknode_count_dict = {'zknode_count_values': zknode_count_list}
        logger.info("Zknode count %s" % zknode_count)
        alert_flag = bool(helper.get_boolean_property('ZOOKEEPER_MONITORING', 'ALERT_REQUIRED'))

        environment = helper.get_property('DEFAULT', 'ENVIRONMENT')
        message = {"notificationChannel": "SLACK", "type": "zknode-count-alert",
                   "data_set": zknode_count_dict, "alertId": alert_id, "environment": environment,
                   "timestamp": str(timestamp), "is_alert": alert_flag}
        json_message = json.dumps(message)
        helpers.post_alert_message(helper.get_property('DEFAULT', 'MESSAGE_POST_URL'), json_message)


def execute_zknode_count_script():
    """
    Execute shell script to get zknode count
    Returns: zknode count list of zookeeper instances

    """
    try:
        dir_path = os.path.dirname(os.path.realpath(__file__))
        zknode_count_script_file = os.path.join(dir_path, 'scripts/fetch_zknode_count.sh')

        deployer_token_path = helper.get_property('DEFAULT', 'DEPLOYER_TOKEN_PATH')

        logger.info("Executing script to get zknode count")
        zknode_count_response = subprocess.Popen(['/bin/bash', zknode_count_script_file, deployer_token_path],
                                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        zknode_count = zknode_count_response.stdout.read().strip().decode("utf-8")
        logger.info(zknode_count)

        return zknode_count

    except subprocess.CalledProcessError as e:
        logger.error("CalledProcessError while executing zknode count script %s" % e.message)
        print("CalledProcessError while executing zknode count script %s" % e.message)


if __name__ == '__main__':
    n = len(sys.argv)
    if n < 3:
        print("Platform and Environment state not provided")
        sys.exit(1)

    helper = Helper(sys.argv[1], sys.argv[2])

    logger.info("Fetching zknode count")
    publish_zknode_count()
