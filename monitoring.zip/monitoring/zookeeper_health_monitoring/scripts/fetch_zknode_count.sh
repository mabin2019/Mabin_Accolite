#!/bin/bash

function main() {
  if [ $# -ne 1 ]; then
    echo "Please enter deployer token with absolute path as argument. Exiting...."
    exit
  fi
  zknode_count=()

  for i in $(/usr/local/bin/kubectl --kubeconfig $1 get pods | grep 'zookeeper' | awk '{print $1}'); do
    zknode_count+=($i:$(/usr/local/bin/kubectl --kubeconfig $1 exec $i -- bash -c "echo mntr | nc localhost 2181 | grep zk_znode_count | tr -d -c 0-9"))
  done

  echo "${zknode_count[@]}"
}
main "$@"
