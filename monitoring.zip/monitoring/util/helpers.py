import configparser
import logging.config
import os

import requests

dir_path = os.path.dirname(os.path.realpath(__file__))


def load_config(platform):
    config = configparser.ConfigParser()
    config.read(dir_path + "/../configs/" + platform + "/monitoring_config.ini")
    return config


def initialize_logger() -> logging.Logger:
    """
    Return a logger with the specified name from ini file
    """
    logging.config.fileConfig(dir_path + '/../configs/logging.ini')
    logger = logging.getLogger('Logger')
    return logger


logger = initialize_logger()


def get_instance(platform, env_state):
    if Helper.instance is None:
        Helper(platform, env_state)
    return Helper.instance


class Helper:
    """
    Helper class to create logger and load config file
    """
    instance = None
    config = None

    def __init__(self, platform, env_state):
        if Helper.instance is not None:
            raise Exception("Singleton Class Exception")
        else:
            self.platform = platform
            self.env_state = env_state
            Helper.config = load_config(platform)
            Helper.instance = self

    def get_property(self, section, key):
        return self.config.get(section, key)

    def get_boolean_property(self, section, key):
        return self.config.getboolean(section, key)


def post_alert_message(url, message):
    """
    Publish a message to a kafka topic

    Arguments:
        message: message to be posted
    """

    logger.info(f'Posting alert message {message}')
    headers = {'content-type': 'application/json'}
    res = requests.post(url, data=message, headers=headers, timeout=30)
    if res.status_code != 200:
        logger.error(f"Got error code {res.status_code} with message {res.content} while posting alert message")
    else:
        logger.info("Alert message posted successfully")
