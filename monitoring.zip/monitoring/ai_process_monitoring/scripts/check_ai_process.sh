#!/bin/bash

function main() {
  if [ $# -ne 1 ]; then
    echo "Please enter deployer token with absolute path as argument. Exiting...."
    exit
  fi

  if [ $(/usr/local/bin/kubectl --kubeconfig $1 get pods | egrep 'ai-python' | wc -l) -eq 0 ]; then
    echo "AI Python pods down"
    exit
  fi

  for i in $(/usr/local/bin/kubectl --kubeconfig $1 get pods | egrep 'ai-python'  | awk '{print $1}'); do
    ai_process=$(/usr/local/bin/kubectl --kubeconfig $1 exec $i -- sh -c "ps -ef | grep -v grep | grep python")
    if [[ -z $ai_process ]];
    then
      ai_pods+=($i)
    fi

  done

  ai_pods_list=$(printf "%s " "${ai_pods[@]}")
  echo "$ai_pods_list"

}

main "$@"