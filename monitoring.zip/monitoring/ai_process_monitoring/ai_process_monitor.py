import json
import os
import subprocess
import sys
import uuid
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from monitoring.util import helpers
from monitoring.util.helpers import Helper

logger = helpers.initialize_logger()


def publish_ai_process_status_message() -> None:
    """
    Publish list of pods which are not running message to Kafka Producer

    """
    ai_process_down_response = execute_process_check_script()

    ai_pods = ai_process_down_response if ai_process_down_response == 'AI Python pods down' else {'pod_names': ai_process_down_response.split(' ')} if ai_process_down_response != '' else {}

    timestamp = datetime.now()
    alert_id = str(uuid.uuid1())
    logger.info("List of pods in which python process is down %s" % ai_process_down_response)
    alert_flag = helper.get_boolean_property('AI_PROCESS_MONITORING', 'ALERT_REQUIRED')
    environment = helper.get_property('DEFAULT', 'ENVIRONMENT')
    message = {"notificationChannel": "SLACK", "type": "ai-process-alert",
               "data_set": ai_pods, "alertId": alert_id, "environment": environment,
               "timestamp": str(timestamp), "is_alert": alert_flag}
    json_message = json.dumps(message)
    print(json_message)
    helpers.post_alert_message(helper.get_property('DEFAULT', 'MESSAGE_POST_URL'), json_message)


def execute_process_check_script() -> str:
    """
    Execute shell script to check if ai-python process is running

    Returns: Shell script decoded response
    """
    dir_path = os.path.dirname(os.path.realpath(__file__))
    ai_process_script_path = os.path.join(dir_path, 'scripts/check_ai_process.sh')

    deployer_token_path = helper.get_property('DEFAULT', 'DEPLOYER_TOKEN_PATH')

    ai_process_script_response = subprocess.Popen(['/bin/bash', ai_process_script_path, deployer_token_path],
                                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    ai_process_status = ai_process_script_response.stdout.read().strip().decode("utf-8")

    return ai_process_status


if __name__ == '__main__':
    n = len(sys.argv)
    if n < 3:
        logger.warning("Platform and Environment state not provided")
        sys.exit(1)

    helper = Helper(sys.argv[1], sys.argv[2])
    logger.info("Checking the status of ai-python process")
    publish_ai_process_status_message()