#!/usr/bin/env bash
function main() {

  DEPLOYER_TOKEN_PATH=$1
  ENVIRONMENT_STATE=$2

  DIRNAME=$(dirname "$0")

  INACTIVE_SITE_BLACKLIST_JOB_PATH=$DIRNAME/inactive_site_blacklist_jobs.txt
  BLACKLIST_JOB_PATH=$DIRNAME/blacklist_jobs.txt

  CREATE_LIST_OF_JOBS

  CREATE_LIST_OF_RUNNING_JOBS

  if [ "$?" -eq "1" ]; then
    echo "Error while executing jobdeployer command"
    exit
  else
  ACTOR_JOBS_NOT_RUNNING=$(ARRAY_DIFFERENCE "${ACTOR_JOBS_LIST[@]}" "${ACTOR_RUNNING_JOBS[@]}")

  FLINK_JOBS_NOT_RUNNING=$(ARRAY_DIFFERENCE "${FLINK_JOBS_LIST[@]}" "${FLINK_RUNNING_JOBS[@]}")

  JOBS_NOT_RUNNING=$(printf "%s " "${FLINK_JOBS_NOT_RUNNING[@]}" "${ACTOR_JOBS_NOT_RUNNING[@]}" | tr '\n' ' ')


  #Discarding jobs from ignored list in active environment
  if [[ "$ENVIRONMENT_STATE" == "INACTIVE" ]]; then
    INACTIVE_SITE_BLACKLIST_JOBS=$(cat $INACTIVE_SITE_BLACKLIST_JOB_PATH | tr '\n' ' ')
    JOBS_NOT_RUNNING=$(ARRAY_DIFFERENCE "${JOBS_NOT_RUNNING[@]}" "${INACTIVE_SITE_BLACKLIST_JOBS[@]}" | tr '\n' ' ')
  fi

    BLACKLIST_JOBS=$(cat $BLACKLIST_JOB_PATH | tr '\n' ' ')
    JOBS_NOT_RUNNING=$(ARRAY_DIFFERENCE "${JOBS_NOT_RUNNING[@]}" "${BLACKLIST_JOBS[@]}" | tr '\n' ' ')

  echo "${JOBS_NOT_RUNNING[@]}"

  fi
}

function CREATE_LIST_OF_JOBS() {

  #Creating actor and flink job names list from jobs.deploy file

  for JOBS_DEPLOY in /opt/pulse/*/conf/jobs.deploy; do

    for key in $(cat $JOBS_DEPLOY); do

      local IS_WORKFLOW=$(printf $key | cut -d ':' -f7)

      local JOB_NAME=$(printf $key | cut -d ':' -f2)

      if [[ "$IS_WORKFLOW" == "workflow" ]]; then

        FLINK_JOBS+=($JOB_NAME)

      else

        ACTOR_JOBS+=($JOB_NAME)

      fi

    done

  done

  ACTOR_JOBS_LIST=$(printf "%s\n" "${ACTOR_JOBS[@]}")
  FLINK_JOBS_LIST=$(printf "%s\n" "${FLINK_JOBS[@]}")

}

function CREATE_LIST_OF_RUNNING_JOBS() {
  #Creating list of running actor and flink jobs through flink and jobdeployer command from JM pod
  /usr/local/bin/kubectl --kubeconfig "$DEPLOYER_TOKEN_PATH" exec flink-jm-0 /opt/flink/bin/jobdeployer list 1>out.txt 2>err.txt
  jobdeployer_err=$(grep "Address already in use" err.txt)
  #Trying again to get jobdeployer list in case of error
  if [ -n "$jobdeployer_err" ]; then
    sleep 10s
    /usr/local/bin/kubectl --kubeconfig "$DEPLOYER_TOKEN_PATH" exec flink-jm-0 /opt/flink/bin/jobdeployer list 1>out.txt 2>err.txt

    jobdeployer_err=$(grep "Address already in use" err.txt)
    #Return error code 1 if jobdeployer cmd fails again
    if [ -n "$jobdeployer_err" ]; then
        return 1
    fi
  fi

  ACTOR_RUNNING_JOBS=$(cat out.txt | grep RUNNING | awk '{print $6}' | cut -f1 -d '(' | sed 's/TimerJob/TimerActorEndpoint/g')
  FLINK_RUNNING_JOBS=$(/usr/local/bin/kubectl --kubeconfig "$DEPLOYER_TOKEN_PATH" exec flink-jm-0 /opt/flink/bin/flink list | grep RUNNING | awk '{print $6}' | cut -f2 -d ".")

}

function ARRAY_DIFFERENCE() {

  ARR1="$1"
  ARR2="$2"

  ARR_UNIQ=$(printf "%s\n" "${ARR1[@]}" "${ARR2[@]}" | tr ' ' '\n' | sort | uniq -u)
  ARR_DIFF=$(printf "%s\n" "${ARR1[@]}" "${ARR_UNIQ[@]}" | tr ' ' '\n' | sort | uniq -d | uniq)

  echo "$ARR_DIFF"

}

main "$@"