#!/usr/bin/python3
import json
import os
import subprocess
import sys
import uuid
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from monitoring.util.helpers import Helper
from monitoring.util import helpers

logger = helpers.initialize_logger()


def publish_jobs_list_message(env) -> None:
    """
    Publish list of jobs which are not running message to Kafka Producer
    """
    jobs_status_response = prepare_jobs_list(env)
    job_status = jobs_status_response if jobs_status_response == 'Error while executing jobdeployer command' else {
        'job_names': jobs_status_response.split(' ')} if jobs_status_response != '' else {}

    timestamp = datetime.now()
    alert_id = str(uuid.uuid1())
    logger.info("List of jobs not running %s" % job_status)
    alert_flag = helper.get_boolean_property('JOB_MONITORING', 'ALERT_REQUIRED')
    environment = helper.get_property('DEFAULT', 'ENVIRONMENT')
    message = {"notificationChannel": "SLACK", "type": "jobs-monitor-alert",
               "data_set": job_status, "alertId": alert_id, "environment": environment,
               "timestamp": str(timestamp), "is_alert": alert_flag}
    json_message = json.dumps(message)
    helpers.post_alert_message(helper.get_property('DEFAULT', 'MESSAGE_POST_URL'), json_message)


def prepare_jobs_list(env) -> str:
    """
    Execute shell script to prepare list of jobs which are not running

    Returns: Shell script decoded response
    """
    dir_path = os.path.dirname(os.path.realpath(__file__))
    jobs_list_script_file = os.path.join(dir_path, 'scripts/retrieve_not_running_jobs.sh')

    deployer_token_path = helper.get_property('DEFAULT', 'DEPLOYER_TOKEN_PATH')

    jobs_list_script_response = subprocess.Popen(['/bin/bash', jobs_list_script_file, deployer_token_path, env],
                                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    jobs_list = jobs_list_script_response.stdout.read().strip().decode("utf-8")
    logger.info(jobs_list)

    return jobs_list


if __name__ == '__main__':
    n = len(sys.argv)
    if n < 3:
        logger.warning("Platform and Environment state not provided")
        sys.exit(1)
    helper = Helper(sys.argv[1], sys.argv[2])
    logger.info("Preparing jobs list")
    publish_jobs_list_message(sys.argv[2])
