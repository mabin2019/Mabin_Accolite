import json
import os
import re
import subprocess
import sys
import uuid
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from monitoring.util import helpers
from monitoring.util.helpers import Helper

logger = helpers.initialize_logger()


def get_disk_utilization():
    try:
        execute_disk_utilization_script()

        dir_path = os.path.dirname(os.path.realpath(__file__))
        disk_utilization_file = os.path.join(dir_path, 'scripts/disk_usage.txt')
        disk_utilization_list = []
        try:
            with open(disk_utilization_file, "r") as f:
                disk_utilization_list = f.readlines()
            disk_utilization_list = [x.strip() for x in disk_utilization_list]
        except FileNotFoundError:
            logger.warning("Disk usage file not found")

        disk_usage_list = []
        for disk_utilization in disk_utilization_list:
            disk_usage_percentage = disk_utilization.split(' ')[2]
            disk_usage_percentage = int(disk_usage_percentage.replace('%', ''))
            if disk_usage_percentage > 90:
                pod_name = disk_utilization.split(' ')[0]
                pod_directory = disk_utilization.split(' ')[1]

                disk_usage_list.append(
                    {"pod_name": pod_name, "pod_directory": pod_directory,
                     "resource_usage_percentage": "{:.1f}".format(disk_usage_percentage) + '%'})

        alert_flag = helper.get_boolean_property('RESOURCE_UTILIZATION_MONITORING', 'ALERT_REQUIRED')

        environment = helper.get_property('DEFAULT', 'ENVIRONMENT')
        disk_utilization = {'disk_utilization': disk_usage_list} if disk_usage_list else {}

        logger.info("Disk utilization map %s" % disk_utilization)
        publish_resource_utilization_message(disk_utilization, "disk-utilization-alert", alert_flag, environment)
    except Exception as e:
        logger.error("Exception while getting disk utilization %s" % e)


def get_resource_utilization():
    try:
        execute_resource_utilization_script()
        cpu_list = []
        mem_list = []
        kafka_mem_list = []
        dir_path = os.path.dirname(os.path.realpath(__file__))
        resource_utilization_file = os.path.join(dir_path, 'scripts/resource_utilization.txt')
        resource_utilization_list = []
        try:
            with open(resource_utilization_file, "r") as f:
                resource_utilization_list = f.readlines()
            resource_utilization_list = [x.strip() for x in resource_utilization_list]
        except FileNotFoundError:
            logger.warning("Resource utilization file not found")
        for resource_utilization in resource_utilization_list:
            pod_name = resource_utilization.split(' ')[0]

            cpu_percentage = get_resource_percentage_utilization_list(pod_name, resource_utilization.split(' ')[1])
            if cpu_percentage:
                cpu_list.append(cpu_percentage)

            mem_percentage = get_resource_percentage_utilization_list(pod_name, resource_utilization.split(' ')[2])
            if mem_percentage:
                if 'kafka' in pod_name:
                    kafka_mem_list.append(mem_percentage)
                else:
                    mem_list.append(mem_percentage)

        alert_flag = helper.get_boolean_property('RESOURCE_UTILIZATION_MONITORING', 'ALERT_REQUIRED')
        environment = helper.get_property('DEFAULT', 'ENVIRONMENT')

        ram_utilization = {'ram_utilization': mem_list} if mem_list else {}

        logger.info("RAM utilization map %s" % ram_utilization)
        publish_resource_utilization_message(ram_utilization, "ram-utilization-alert", alert_flag, environment)

        if kafka_mem_list:
            kafka_ram_alert_flag = False
            ram_utilization = {'ram_utilization': kafka_mem_list}

            logger.info("RAM utilization map %s" % ram_utilization)
            publish_resource_utilization_message(ram_utilization, "ram-utilization-alert", kafka_ram_alert_flag, environment)

        cpu_utilization = {'cpu_utilization': cpu_list} if cpu_list else {}

        logger.info("CPU utilization map %s" % cpu_utilization)
        publish_resource_utilization_message(cpu_utilization, "cpu-utilization-alert", alert_flag, environment)
    except Exception as e:
        logger.error("Exception while getting resource utilization %s" % e)


def publish_resource_utilization_message(resource_utilization, alert_type, alert_flag, environment):
    timestamp = datetime.now()
    alert_id = str(uuid.uuid1())

    message = {"notificationChannel": "SLACK", "type": alert_type,
               "data_set": resource_utilization, "alertId": alert_id, "environment": environment,
               "timestamp": str(timestamp), "is_alert": alert_flag}
    json_message = json.dumps(message)
    helpers.post_alert_message(helper.get_property('DEFAULT', 'MESSAGE_POST_URL'), json_message)


def get_resource_percentage_utilization_list(pod_name, resource):
    resource_utilization_percent = re.findall('\d*\.?\d+', resource)
    resource_utilization_percent = float(''.join(resource_utilization_percent))
    if resource_utilization_percent > 90:
        resource_dict = {"pod_name": pod_name,
                         "resource_usage_percentage": "{:.1f}".format(resource_utilization_percent) + "%"}
        return resource_dict


def execute_resource_utilization_script():
    """
    Execute shell script to get resource utilization of all pods

    """
    try:
        dir_path = os.path.dirname(os.path.realpath(__file__))
        resource_utilization_script_file = os.path.join(dir_path, 'scripts/calculate_resource_utilization.sh')

        deployer_token_path = helper.get_property('DEFAULT', 'DEPLOYER_TOKEN_PATH')

        logger.info("Executing script to get resource utilization")
        resource_utilization_script_response = subprocess.Popen(['/bin/bash', resource_utilization_script_file,
                                                                 deployer_token_path],
                                                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = resource_utilization_script_response.communicate()
    except subprocess.CalledProcessError as e:
        logger.error("CalledProcessError while executing resource utilization script %s" % e.message)
        print("CalledProcessError while executing resource utilization script %s" % e.message)


def execute_disk_utilization_script():
    """
    Execute shell script to get disk utilization of all pods

    """
    try:
        dir_path = os.path.dirname(os.path.realpath(__file__))
        disk_utilization_script_file = os.path.join(dir_path, 'scripts/calculate_disk_utilization.sh')

        deployer_token_path = helper.get_property('DEFAULT', 'DEPLOYER_TOKEN_PATH')

        logger.info("Executing script to get disk utilization")
        disk_utilization_script_response = subprocess.Popen(['/bin/bash', disk_utilization_script_file,
                                                             deployer_token_path],
                                                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = disk_utilization_script_response.communicate()

    except subprocess.CalledProcessError as e:
        logger.error("CalledProcessError while executing disk utilization script %s" % e.message)
        print("CalledProcessError while executing disk utilization script %s" % e.message)


if __name__ == "__main__":
    n = len(sys.argv)
    if n < 3:
        logger.warning("Platform and Environment state not provided")
        sys.exit(1)

    helper = Helper(sys.argv[1], sys.argv[2])

    logger.info("Getting resource utilization of pods")
    get_resource_utilization()
    logger.info("Getting disk utilization of pods")
    get_disk_utilization()
