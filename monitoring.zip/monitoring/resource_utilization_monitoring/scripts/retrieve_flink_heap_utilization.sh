#!/bin/bash
function main() {
  DIRNAME=$(dirname "$0")
  rm -rf ${DIRNAME}/heap_memory_utilization.txt
  if [ $# -lt 1 ]; then
    echo "Please enter deployer token with absolute path as argument. Exitting...."
    exit
  fi
  if [ $(/usr/local/bin/kubectl --kubeconfig $1 get pods | grep 'flink-tm' | awk '{print $1}' | wc -l) -eq 0 ]; then
    echo "The deployer token entered is not proper. Please check again."
    exit
  fi
  for i in $(/usr/local/bin/kubectl --kubeconfig $1 get pods | grep -e 'flink-jm' -e 'flink-tm-' | awk '{print $1}'); do
    heap_memory_usage=$(/usr/local/bin/kubectl --kubeconfig $1 exec -it $i -- bash -c "cd /opt/flink/bin/tools; jmx-client.sh 127.0.0.1:1099 get java.lang:type=Memory HeapMemoryUsage")

    committed_mem=$(echo "$heap_memory_usage" | grep -w 'HeapMemoryUsage' | awk -F'committed=' '{print $2}' | cut -f1 -d',')
    used_mem=$(echo "$heap_memory_usage" | grep -w 'HeapMemoryUsage' | awk -F'used=' '{print $2}' | cut -f1 -d'}')
    echo $i "$committed_mem" "$used_mem" >>${DIRNAME}/heap_memory_utilization.txt
  done
}

main "$@"