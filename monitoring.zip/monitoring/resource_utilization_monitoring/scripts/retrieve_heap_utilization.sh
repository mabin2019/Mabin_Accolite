#!/bin/bash
function main() {

  deployer_token=$1
  service_name=$2
  max_heap_metric_name=$3
  used_heap_metric_name=$4


  metrics_endpoints=$(/usr/local/bin/kubectl --kubeconfig $deployer_token get endpoints $service_name -o json)
  metrics_ips=$(echo "$metrics_endpoints" | /usr/bin/jq -r '.subsets[].addresses[] | "\(.hostname):\(.ip)"' | tr '\n' ' ')
  metrics_port=$(echo "$metrics_endpoints" | /usr/bin/jq -r '.subsets[].ports[] | select(.name == "metrics") | with_entries(select(.key == "port"))' | /usr/bin/jq -r '.port')

  for pod_instance in $metrics_ips; do
    pod_name=$(echo "$pod_instance" | cut -d':' -f1)
    metrics_ip=$(echo "$pod_instance" | cut -d':' -f2)
    metrics=$(curl -k -s "http://$metrics_ip:$metrics_port/metrics")
    heap_allocated=$(echo "$metrics" | grep $max_heap_metric_name | grep -v '#' | head -1 | cut -d' ' -f2)
    heap_used=$(echo "$metrics" | grep  $used_heap_metric_name | grep -v '#' | head -1 | cut -d' ' -f2)
    echo "$pod_name $heap_allocated $heap_used"
  done
}

main "$@"