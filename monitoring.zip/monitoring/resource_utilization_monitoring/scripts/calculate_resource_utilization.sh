#!/bin/bash
function main() {
  if [ $# -ne 1 ]; then
    echo "Please enter deployer token with absolute path as argument. Exiting...."
    exit
  fi

DEPLOYER_TOKEN=$1

  DIRNAME=$(dirname "$0")

  top_pods=($(/usr/local/bin/kubectl --kubeconfig $DEPLOYER_TOKEN top pods | grep -v 'deploymentpod' | sed '1d' | awk '{print $1":"$2":"$3}'))

  rm -rf ${DIRNAME}/resource_utilization.txt
  for i in "${top_pods[@]}"; do

    pod_name=$(echo $i | cut -d':' -f1)
    cpu_used=$(echo $i | cut -d':' -f2)
    ram_used=$(echo $i | cut -d':' -f3)

    ram_used_unit=$(echo "${ram_used: -2}")
    ram_used=$(echo "${ram_used%??}")

    if [[ "$ram_used_unit" == "Gi" ]]; then
      ((ram_used = 1024 * ram_used))
    fi

    cpu_used_unit=$(echo "${cpu_used: -1}")

    if [[ "$cpu_used_unit" == "m" ]]; then

      cpu_used=$(echo "${cpu_used%?}")

    else

      ((cpu_used = 1000 * cpu_used))

    fi

    total_cpu_allocated=0

    total_ram_allocated=0

    calculate_total_resource_allocation $pod_name

    calculate_resource_utilization_percent $pod_name


  done

}

function calculate_total_resource_allocation() {

  pod_name=$1

  cpu_allocated_list=($(/usr/local/bin/kubectl --kubeconfig $DEPLOYER_TOKEN get pod $pod_name -o json | jq '.spec.containers[].resources.limits.cpu' | tr '\n' ' ' | tr -d '"'))

  ram_allocated_list=($(/usr/local/bin/kubectl --kubeconfig $DEPLOYER_TOKEN get pod $pod_name -o json | jq '.spec.containers[].resources.limits.memory' | tr '\n' ' ' | tr -d '"'))


  # total_cpu_allocated=$(IFS=+; echo "$((${cpu_allocated_list[*]}))")

  total_ram_allocated=0

  for ram_allocated in "${ram_allocated_list[@]}"; do

    ram_allocated_unit=$(echo "${ram_allocated: -2}")

    ram_allocated_val=$(echo "${ram_allocated%??}")

    if [[ "$ram_allocated_unit" == "Gi" ]]; then
      ((ram_allocated_val = 1024 * ram_allocated_val))
    fi

    total_ram_allocated=$(expr $total_ram_allocated + $ram_allocated_val)

  done
  total_cpu_allocated=0

  for cpu_allocated in "${cpu_allocated_list[@]}"; do

    cpu_allocated_unit=$(echo "${cpu_allocated: -1}")

    if [[ "$cpu_allocated_unit" == "m" ]]; then
      cpu_allocated=$(echo "${cpu_allocated%?}")
    else
      ((cpu_allocated = 1000 * cpu_allocated))
    fi

    total_cpu_allocated=$(expr $total_cpu_allocated + $cpu_allocated)

  done


}

function calculate_resource_utilization_percent() {

  pod_name=$1

  #RegEx to validate percentage

  regEx=[0-9]*\.[0-9]+

  if [[ $total_cpu_allocated =~ $regEx ]]; then

    if [ -n "$cpu_used" ] && [ -n "$total_cpu_allocated" ]; then

      #Calculating cpu usage percentage ( usage % = used_value/allocated_value * 100%)

      cpu_percent=$(echo "$cpu_used" "$total_cpu_allocated" | awk '{print ($1*100)/$2}')

    fi

  fi

  if [[ $total_ram_allocated =~ $regEx ]]; then

    if [ -n "$ram_used" ] && [ -n "$total_ram_allocated" ]; then

      #Calculating mem usage percentage ( usage % = used_value/allocated_value * 100%)

      mem_percent=$(echo "$ram_used" "$total_ram_allocated" | awk '{print ($1*100)/$2}')


    fi

  fi

  if [ -n "$cpu_percent" ] && [ -n "$mem_percent" ]; then
    echo $pod_name cpu:$cpu_percent"%" mem:$mem_percent"%" >>${DIRNAME}/resource_utilization.txt
  fi

}

main "$@"
