#!/bin/bash

function main() {
DIRNAME=$(dirname "$0")

  if [ $# -ne 1 ]; then

    echo "Please enter deployer token with absolute path as argument. Exiting...."

    exit

  fi

  echo -n "" >${DIRNAME}/disk_usage.txt

  for i in $(/usr/local/bin/kubectl --kubeconfig $1 get pods | egrep -v 'deploymentpod' | sed '1d' | awk '{print $1}'); do

    mount_path=$(/usr/local/bin/kubectl --kubeconfig $1 get pod $i -o json | jq -r '.spec.containers[].volumeMounts[].mountPath' | sort | uniq)

    for pvc in ${mount_path[@]}; do

      pvc_dir=$(echo ${pvc##*/} | fgrep .)

      if [ -z ${pvc_dir} ]; then



        disk_usage=$(/usr/local/bin/kubectl --kubeconfig $1 exec $i -- sh -c "df -h ${pvc}" | grep ${pvc} | grep -o '[^ ]*%')

        if [ ! -z $disk_usage ]; then



          echo "$i ${pvc} ${disk_usage}" >>${DIRNAME}/disk_usage.txt

        fi

      fi

    done

  done

}

main "$@"