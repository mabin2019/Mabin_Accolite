import configparser
import json
import os
import subprocess
import sys
import uuid
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from monitoring.util import helpers
from monitoring.util.helpers import Helper

logger = helpers.initialize_logger()


def get_heap_utilization():
    try:
        logger.info("Fetching heap allocated and used memory in bytes")
        pods_heap_usage_list = execute_heap_utilization_script()
        heap_usage_list = []
        for heap_usage in pods_heap_usage_list:
            if heap_usage:
                pod_name = heap_usage.split(' ')[0]
                if 'flink' in pod_name:
                    allocated_heap = heap_usage.split(' ')[1]
                    used_heap = heap_usage.split(' ')[2]
                else:
                    allocated_heap = float(heap_usage.split(' ')[1]) / (1024 * 1024 * 1024)
                    used_heap = float(heap_usage.split(' ')[2]) / (1024 * 1024 * 1024)
                heap_usage_percentage = float(used_heap / allocated_heap * 100)
                if heap_usage_percentage > 90:
                    heap_usage_list.append({"pod_name": pod_name,
                                            "resource_usage_percentage": "{:.1f}".format(heap_usage_percentage) + "%"})
        heap_utilization = {'heap_utilization': heap_usage_list} if heap_usage_list else {}

        alert_flag = helper.get_boolean_property('RESOURCE_UTILIZATION_MONITORING', 'ALERT_REQUIRED')

        environment = helper.get_property('DEFAULT', 'ENVIRONMENT')

        timestamp = datetime.now()
        alert_id = str(uuid.uuid1())
        logger.info("Heap utilization map %s" % heap_utilization)

        message = {"notificationChannel": "SLACK", "type": "heap-utilization-alert",
                   "data_set": heap_utilization, "alertId": alert_id, "environment": environment,
                   "timestamp": str(timestamp), "is_alert": alert_flag}
        json_message = json.dumps(message)
        helpers.post_alert_message(helper.get_property('DEFAULT', 'MESSAGE_POST_URL'), json_message)
    except Exception as e:
        logger.error("Exception while getting heap utilization %s" % e)


def execute_heap_utilization_script():
    """
    Execute shell script to get heap utilization
    """
    try:
        dir_path = os.path.dirname(os.path.realpath(__file__))
        heap_utilization_script_file = os.path.join(dir_path, 'scripts/retrieve_heap_utilization.sh')
        flink_heap_utilization_script_file = os.path.join(dir_path, 'scripts/retrieve_flink_heap_utilization.sh')
        deployer_token_path = helper.get_property('DEFAULT', 'DEPLOYER_TOKEN_PATH')

        logger.info("Executing script to get heap utilization")
        dir_path = os.path.dirname(os.path.realpath(__file__))
        heap_usage_conf = configparser.ConfigParser()
        heap_usage_conf.read(dir_path + "/configs/heap_utilization_conf.ini")

        heap_usage_list = []

        flink_heap_utilization_script_response = subprocess.Popen(['/bin/bash', flink_heap_utilization_script_file,
                                                                   deployer_token_path],
                                                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        for pod in heap_usage_conf.sections():

            heap_utilization_script_response = subprocess.Popen(
                ['/bin/bash', heap_utilization_script_file, deployer_token_path,
                 heap_usage_conf.get(pod, 'SERVICE_NAME'), heap_usage_conf.get(pod, 'HEAP_MAX_METRIC_NAME'),
                 heap_usage_conf.get(pod, 'HEAP_USED_METRIC_NAME')], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            heap_usage_response = heap_utilization_script_response.stdout.read().decode("utf-8")

            heap_usage_list.extend(heap_usage_response.split('\n'))

            heap_utilization_file_path = os.path.join(dir_path, 'scripts/heap_memory_utilization.txt')

        with open(heap_utilization_file_path, 'a') as heap_utilization_file:
            for row in heap_usage_list:
                heap_utilization_file.write("%s\n" % row)
        return heap_usage_list

    except subprocess.CalledProcessError as e:
        logger.error("CalledProcessError while executing heap utilization script %s" % e.message)
        print("CalledProcessError while executing heap utilization script %s" % e.message)


if __name__ == "__main__":
    n = len(sys.argv)
    if n < 3:
        print("Platform and Environment state not provided")
        sys.exit(1)

    helper = Helper(sys.argv[1], sys.argv[2])

    logger.info("Getting resource utilization of pods")
    get_heap_utilization()