import json
import os
import sys
import configparser

import flask
from flask import request

from alerting.util import helpers
from alerting.util.helpers import Helper

logger = helpers.initialize_logger()
app = flask.Flask(__name__)


@app.route('/api/post/message', methods=['POST'])
def fetch_alert_messages():
    try:
        platform = app.config['platform']
        message = request.data

        alert_message = json.loads(message)
        logger.info(f"Received message {alert_message}")
        alert_type = alert_message['type']
        is_alert = None if 'is_alert' not in alert_message else bool(alert_message['is_alert'])

        message_processor_instance = helpers.type_to_message_processor(alert_type)
        if message_processor_instance:
            message_processor_module_str = ('alerting', 'messageprocessor', message_processor_instance.split(",")[0])
            # Instantiate class instance of message processor based on alert type
            message_processor_class_instance = helpers.instantiate_class(
                '.'.join(message_processor_module_str),
                message_processor_instance.split(",")[1], platform, os.environ['ENV_CLUSTER'], os.environ['NAMESPACE'])

            message_body = message_processor_class_instance.form_alert_message(alert_message)
            if message_body:
                notification_sender_class_instance = helpers.get_notification_sender_class_instance(alert_message)

                if alert_message['notificationChannel'] == 'EMAIL':
                    notification_sender_class_instance().send_notification(message_body,
                                                                           channel_config=dict(config.items('EMAIL')))
                else:
                    slack_config = {}
                    if not is_alert:
                        slack_config["webhook_url"] = helper.get_property('MONITORING', 'WEBHOOK_URL')
                    else:
                        slack_config["webhook_url"] = helper.get_property('ALERTING', 'WEBHOOK_URL')
                    slack_config["base_url"] = helper.get_property('SLACK', 'BASE_URL')
                    notification_sender_class_instance().send_notification(message_body, channel_config=slack_config)

            logger.info("Writing %s alert message to file" % alert_type)
            with open('/tmp/' + alert_type + '.json', 'w') as f:
                json.dump(alert_message, f)
        return "Success"
    except Exception as e:
        logger.error("Error while consuming alert messages from kafka :: %s" % e)
        return f"Exception : {e}"


if __name__ == '__main__':
    n = len(sys.argv)
    if n < 3:
        print("Platform and Environment state not provided")
        sys.exit(1)
    platform = sys.argv[1]
    env_state = sys.argv[2]

    # Initializing helper class with platform and env_state
    helper = Helper(platform=platform, env_state=env_state)
    config = helper.config
    app.config['platform'] = platform

    app.run(host='0.0.0.0', port=5000)
