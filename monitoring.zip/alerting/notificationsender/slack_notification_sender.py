import requests

from alerting.notificationsender import notification_sender
from alerting.util import helpers

logger = helpers.initialize_logger()


class SlackNotificationSender(notification_sender.NotificationSender):

    def send_notification(self, message, channel_config) -> None:
        url = channel_config.get('base_url') + channel_config.get('webhook_url')
        logger.info(url)
        headers = {}
        logger.info("Sending alert message %s to slack" % message)
        logger.info("Sending alert message %s to slack" % url)
        try:
            res = requests.post(url, data=message, headers=headers, timeout=30)
        except Exception as e:
            logger.error("Error while posting messages to slack %s" % e)
