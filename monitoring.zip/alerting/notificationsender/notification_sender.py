import abc


class NotificationSender(abc.ABC):
    @abc.abstractmethod
    def send_notification(self, message, channel_config) -> None:
        """
        Posts notification message to the channel
        Arguments:
            channel_config: config for notification channel
            message: Message to be sent to the notification channel
        """
        pass





