import smtplib

from alerting.notificationsender import notification_sender
from alerting.util import helpers

logger = helpers.initialize_logger()


class EmailNotificationSender(notification_sender.NotificationSender):

    def send_notification(self, message, channel_config) -> None:
        try:
            smtp_host = channel_config.get('smtp_host')
            smtp_port = channel_config.get('smtp_port')

            recipients = channel_config.get('mail_recipients_list')

            logger.info("Sending mail with sanity report")
            s = smtplib.SMTP(host=smtp_host, port=smtp_port)

            recipients = recipients.split(",")
            sender = channel_config.get('email_address')

            message['From'] = sender
            message['To'] = ", ".join(recipients)
            s.sendmail(sender, recipients, message.as_string())
            logger.info("Successfully sent mail with sanity test report")
        except Exception as e:
            logger.error("Exception while sending email :: %s" % e)
