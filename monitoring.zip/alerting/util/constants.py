success_color_code = "#18A558"
failure_color_code = "#C70039"
report_color_code = "#009ACD"
