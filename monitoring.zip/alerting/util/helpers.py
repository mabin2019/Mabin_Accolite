import logging.config
import os
import configparser
import importlib
from typing import Any

dir_path = os.path.dirname(os.path.realpath(__file__))


def initialize_logger() -> logging.Logger:
    """
    Return a logger with the specified name from ini file
    """
    logging.config.fileConfig(dir_path + '/../configs/logging.ini')
    logger = logging.getLogger('Logger')
    return logger


def get_instance(platform, env_state):
    if Helper.instance is None:
        Helper(platform, env_state)
    return Helper.instance


def load_config(platform):
    config = configparser.ConfigParser()
    config.read(dir_path + "/../configs/" + platform + "/alerting_config.ini")
    return config


class Helper:
    """
    Helper class to create logger and load config file
    """
    instance = None
    config = None

    def __init__(self, platform, env_state):
        if Helper.instance is not None:
            raise Exception("Singleton Class Exception")
        else:
            self.platform = platform
            self.env_state = env_state
            Helper.config = load_config(platform)
            Helper.instance = self

    def get_property(self, section, key):
        return self.config.get(section, key)


logger = initialize_logger()


def instantiate_class(module_name, class_name, *args):
    """
    Instantiate class instance

    Arguments:
        module_name: Name of module in which the class to be instantiated resides
        class_name: Name of the class to be instantiated
    Returns: class instance
    """
    class_instance = None
    try:
        module_ = importlib.import_module(module_name)
        try:
            if args:
                class_instance = getattr(module_, class_name)(*args)
            else:
                class_instance = getattr(module_, class_name)
        except AttributeError:
            logger.error('Class does not exist')
    except ImportError:
        logger.error('Module does not exist')
    return class_instance


def channel_to_notification_sender_class(argument):
    switcher = {
        'SLACK': 'SlackNotificationSender',
        'EMAIL': 'EmailNotificationSender'
    }
    return switcher.get(argument)


def type_to_message_processor(argument):
    switcher = {
        'jobs-monitor-alert': 'process_status_message_processor,ProcessStatusMessageProcessor',
        'pods-monitor-alert': 'process_status_message_processor,ProcessStatusMessageProcessor',
        'ram-utilization-alert': 'resource_utilization_message_processor,ResourceUtilizationMessageProcessor',
        'cpu-utilization-alert': 'resource_utilization_message_processor,ResourceUtilizationMessageProcessor',
        'heap-utilization-alert': 'resource_utilization_message_processor,ResourceUtilizationMessageProcessor',
        'disk-utilization-alert': 'resource_utilization_message_processor,ResourceUtilizationMessageProcessor',
        'zknode-count-alert': 'zknode_count_message_processor,ZKNodeCountMessageProcessor',
        'druid-health-alert': 'druid_health_message_processor,DruidHealthMessageProcessor',
        'expired-timer-alert': 'expired_timer_message_processor,ExpiredTimerMessageProcessor',
        'ai-process-alert': 'ai_process_message_processor,AIProcessStatusMessageProcessor',
        'sanity-report-generated-event': 'sanity_report_processor,SanityReportProcessor'
    }
    return switcher.get(argument)


def get_notification_sender_class_instance(message):
    notification_channel = get_message_property(message, 'notificationChannel')

    notification_sender_class_name = channel_to_notification_sender_class(notification_channel)

    notification_sender_class_name_str = (notification_channel.lower(), 'notification', 'sender')
    notification_sender_module_str = ('alerting', 'notificationsender', '_'.join(notification_sender_class_name_str))
    notification_sender_class_instance = instantiate_class('.'.join(notification_sender_module_str),
                                                           notification_sender_class_name)

    return notification_sender_class_instance


def get_message_property(message, property_key) -> Any:
    """
    Retrieves property value from message dict

    Arguments:
        message: Message dict
        property_key: Property key
    Returns: Property value from message dict
    """
    return message.get(property_key)
