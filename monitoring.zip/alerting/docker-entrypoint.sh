#!/bin/bash
set -x
PLATFORM=$1
ENV_STATE=$2

echo "Executing job alerting task"
/usr/bin/python3 /apps/main.py "$PLATFORM" "$ENV_STATE" &
tail -f /dev/null