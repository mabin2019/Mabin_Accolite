import csv
from typing import Any
from alerting.util.helpers import Helper

from alerting.util import helpers
from alerting.messageprocessor import message_processor
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os

logger = helpers.initialize_logger()


class SanityReportProcessor(message_processor.MessageProcessor):
    def __init__(self, platform, env_cluster, namespace) -> None:
        self.platform = platform
        self.env_cluster = env_cluster
        self.namespace = namespace

    def form_alert_message(self, message) -> str:
        try:
            data_set = message['data_set']
            sanity_result_payloads_filepath = data_set['sanity_result_payloads_filepath']
            failed_payloads_path, failed_payloads_file = os.path.split(sanity_result_payloads_filepath)

            environment = message['environment']

            logger.info("Parsing sanity report")

            alert_message_body = self.process_message(message)

            email_message = MIMEMultipart()
            email_message['Subject'] = "{} {} - Sanity Test Report".format(environment, self.env_cluster)

            report_download_url = Helper.config.get('TESTING', 'REPORT_DOWNLOAD_URL')
            text = 'Please find below sanity test report for {} {}.'.format(environment,
                                                                            self.env_cluster)

            html = "<html><head><title></title><style>" \
                   "table, td, th " \
                   "{border: 1px solid black; text-align: center;} " \
                   "table {width: 50%;border-collapse: collapse;}" \
                   "</style></head><body><p style='text-align:left'>"
            html += text
            html += '<br><a href="' + report_download_url.replace('NAMESPACE', self.namespace) + failed_payloads_file + '">Click Here</a> to download the sanity test result payloads.'
            html += "</p><br><br><table border='1'> <tr><th>Operation Name</th><th>Response Message</th></tr>"
            for operation_status in alert_message_body:
                operation = operation_status.get('operation_name')
                response_code = operation_status.get('response')
                html += "<tr><td>{}</td>".format(operation)
                html += "<td><font color={}>{}</font></td>".format('green' if response_code == 'Success' else 'red',
                                                                   response_code)
                html += "</tr>"
            html += "</table><br><br>"
            html += "</body></html>"
            html_part = MIMEText(html, 'html', 'utf-8')
            email_message.attach(html_part)

            return email_message
        except Exception as e:
            logger.error('Exception while forming alert message :: %s' % e)
            return None

    def str_to_bool(self, string):
        if string == 'True' or string == 'true':
            return True
        elif string == 'False' or string == 'false':
            return False
        else:
            raise ValueError

    def process_message(self, message) -> Any:
        logger.info("Processing sanity report")
        try:
            data_set = message['data_set']
            sanity_report_filepath = data_set['test_report_filepath']

            operation_rows = []

            with open(sanity_report_filepath,
                      'r') as csvfile:
                csvreader = csv.reader(csvfile)

                for row in csvreader:
                    operation_rows.append(row)

                success_response_list = []
                failure_response_list = []
                # Discarding first 2 lines in report (headers and websocket connection)
                for row in operation_rows[2:]:
                    operation_name = row[2]
                    success_flag = self.str_to_bool(row[7])
                    if not success_flag:
                        message = row[8]
                        if message == '':
                            message = 'Failure, empty assertion message'
                        failure_response_list.append({"operation_name": operation_name, "response": message})

                    else:
                        message = 'Success'
                        success_response_list.append({"operation_name": operation_name, "response": message})

            return failure_response_list + success_response_list

        except Exception as e:
            logger.error("Error while parsing sanity report :: %s" % e)
