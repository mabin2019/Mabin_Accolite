from typing import Any
import json
from alerting.util import helpers, constants
from alerting.messageprocessor import message_processor
from os import path

logger = helpers.initialize_logger()


class ResourceUtilizationMessageProcessor(message_processor.MessageProcessor):
    def __init__(self, platform, env_cluster, namespace) -> None:
        self.platform = platform
        self.env_cluster = env_cluster
        self.namespace = namespace

    def form_alert_message(self, message) -> str:
        environment = helpers.get_message_property(message, 'environment')
        alert_type = helpers.get_message_property(message, 'type')
        platform = 'DPAS' if self.platform == 'dpas' else 'OnePulse'

        resource_type = (alert_type.split('-')[0]).upper() if ((alert_type.split('-')[0]) == 'ram'
                                                               or (alert_type.split('-')[0]) == 'cpu') \
            else (alert_type.split('-')[0]).capitalize()

        alert_type = helpers.get_message_property(message, 'type')
        is_alert = helpers.get_message_property(message, 'is_alert')

        logger.info("Reading latest alert message for type %s" % alert_type)
        latest_alert_message = {}
        alert_message_file_path = '/tmp/' + alert_type + '.json'
        if path.isfile(alert_message_file_path):
            with open(alert_message_file_path) as latest_alert_message_file:
                latest_alert_message = json.load(latest_alert_message_file)
        resource_usage_values = self.process_message(message, resource_type)
        message_attachment_list = []

        if resource_usage_values:
            attachment_fields = [{"title": "Pod Name", "short": json.dumps(True)},
                                 {"title": f"{resource_type} Utilization(%)",
                                  "short": json.dumps(True)}]
            for resource_dict in resource_usage_values:
                attachment_fields.append({"value": resource_dict['pod_name'] + (' - ' + resource_dict['pod_directory']
                                                                                if resource_type == 'Disk' else ''),
                                          "short": json.dumps(True)})
                attachment_fields.append(
                    {"value": resource_dict['resource_usage_percentage'], "short": json.dumps(True)})

            message_attachment_list = [{"fields": attachment_fields, "color": constants.failure_color_code,
                                        "title": f"ALERT! {resource_type} Utilization spike in {platform} {environment} {self.env_cluster} environment"}]

        else:
            if bool(latest_alert_message) and bool(latest_alert_message['data_set'])  and 'is_alert' in latest_alert_message and latest_alert_message['is_alert'] == is_alert:
                message_attachment_list = [{"color": constants.success_color_code,
                                            "title": f"{resource_type} Utilization within limits in {platform} {environment} {self.env_cluster} environment"}]

        if message_attachment_list:
            alert_message = json.dumps({"attachments": message_attachment_list})
            return alert_message

    def process_message(self, message, resource_type) -> Any:
        logger.info("Processing resource utilization alert message")
        try:
            data_set = message['data_set']
            if not data_set:
                return None
            resource_utilization_map = data_set[next(iter(data_set))]

            return resource_utilization_map
        except Exception as e:
            logger.error("Error while extracting resource utilization alert messages data set :: %s" % e)
            print("Error while extracting resource utilization alert messages data set :: %s" % e)
