from typing import Any
import json
from alerting.util import helpers, constants
from alerting.messageprocessor import message_processor
from os import path

logger = helpers.initialize_logger()


class ExpiredTimerMessageProcessor(message_processor.MessageProcessor):
    def __init__(self, platform, env_cluster, namespace) -> None:
        self.platform = platform
        self.env_cluster = env_cluster
        self.namespace = namespace

    def form_alert_message(self, message) -> str:
        environment = helpers.get_message_property(message, 'environment')
        alert_type = helpers.get_message_property(message, 'type')
        platform = 'DPAS' if self.platform == 'dpas' else 'OnePulse'

        logger.info("Reading latest alert message for type %s" % alert_type)
        latest_alert_message = {}
        alert_message_file_path = '/tmp/' + alert_type + '.json'
        if path.isfile(alert_message_file_path):
            with open(alert_message_file_path) as latest_alert_message_file:
                latest_alert_message = json.load(latest_alert_message_file)

        message_attachment_list = []
        timer_ids_map = self.process_message(message)
        if timer_ids_map:
            attachment_fields = [{"title": "Timer Region", "short": json.dumps(True)},
                                 {"title": "Next Fire Time (in UTC)", "short": json.dumps(True)}]
            for timer in timer_ids_map:
                attachment_fields.append({"value": timer['region'],
                                          "short": json.dumps(True)})
                attachment_fields.append({"value": timer['nextFireTime'],
                                      "short": json.dumps(True)})

            message_attachment_list = [{"fields": attachment_fields, "color": constants.failure_color_code,
                                        "title": f"ALERT! Challenge Timers with expired fire time in {platform} {environment} {self.env_cluster} environment"}]

        if message_attachment_list:
            alert_message = json.dumps({"attachments": message_attachment_list})
            return alert_message

    def process_message(self, message) -> Any:
        logger.info("Processing expired timer alert message")
        try:
            data_set = message['data_set']
            if not data_set:
                return None
            timer_ids_map = data_set[next(iter(data_set))]

            return timer_ids_map
        except Exception as e:
            logger.error("Error while extracting expired timer alert messages data set :: %s" % e)
