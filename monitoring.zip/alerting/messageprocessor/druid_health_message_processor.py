from typing import Any
import json
from alerting.util import helpers, constants
from alerting.messageprocessor import message_processor
from os import path

logger = helpers.initialize_logger()


class DruidHealthMessageProcessor(message_processor.MessageProcessor):
    def __init__(self, platform, env_cluster, namespace) -> None:
        self.platform = platform
        self.env_cluster = env_cluster
        self.namespace = namespace

    def form_alert_message(self, message) -> str:
        environment = helpers.get_message_property(message, 'environment')
        alert_type = helpers.get_message_property(message, 'type')
        platform = 'DPAS' if self.platform == 'dpas' else 'OnePulse'

        logger.info("Reading latest alert message for type %s" % alert_type)
        latest_alert_message = {}
        alert_message_file_path = '/tmp/' + alert_type + '.json'
        if path.isfile(alert_message_file_path):
            with open(alert_message_file_path) as latest_alert_message_file:
                latest_alert_message = json.load(latest_alert_message_file)

        if bool(latest_alert_message) and latest_alert_message[
            'data_set'] == 'Error response while getting druid supervisor list' and \
                message['data_set'] == 'Error response while getting druid supervisor list':
            message_attachment_list = [{"color": constants.failure_color_code,
                                        "title": f"ALERT! Error response while getting druid supervisor list in "
                                                 f"{platform} {environment} {self.env_cluster} environment"}]

            return json.dumps({"attachments": message_attachment_list})

        message_attachment_list = []
        supervisor_health_status = self.process_message(message)
        if supervisor_health_status:
            attachment_fields = [{"title": "Supervisor Region", "short": json.dumps(True)},
                                 {"title": "Health Status",
                                  "short": json.dumps(True)}]
            for supervisor_health in supervisor_health_status:
                attachment_fields.append({"value": supervisor_health['name'],
                                          "short": json.dumps(True)})
                attachment_fields.append(
                    {"value": supervisor_health['status'], "short": json.dumps(True)})

            message_attachment_list = [{"fields": attachment_fields, "color": constants.failure_color_code,
                                        "title": f"ALERT! Unhealthy Druid Supervisors in {platform} {environment} {self.env_cluster} environment"}]

        else:
            if bool(latest_alert_message) and bool(latest_alert_message['data_set']):
                message_attachment_list = [{"color": constants.success_color_code,
                                            "title": f"All the Druid Supervisors are healthy in {platform} {environment} {self.env_cluster} environment"}]

        if message_attachment_list:
            alert_message = json.dumps({"attachments": message_attachment_list})
            return alert_message

    def process_message(self, message) -> Any:
        logger.info("Processing druid health alert message")
        try:
            data_set = message['data_set']
            if not data_set:
                return None
            druid_health_map = data_set[next(iter(data_set))]

            return druid_health_map
        except Exception as e:
            logger.error("Error while extracting druid health status alert messages data set :: %s" % e)
