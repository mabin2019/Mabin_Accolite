import abc
from typing import Any


class MessageProcessor(abc.ABC):
    @abc.abstractmethod
    def process_message(self, message) -> Any:
        """
        Extracts alert message data set body

        Arguments:
            message: Alert json str message to be processed
        Returns: Alert message data set
        """
        pass

    @abc.abstractmethod
    def form_alert_message(self, environment, message) -> str:
        """
        Constructs alert message to be sent to notification channel from processed message

        Arguments:
            message: Alert message data set
            environment: Environment for which alert messages to be sent
        Returns: Constructed alert message str.
        """
        pass
