from typing import Any
import json
from alerting.util import helpers, constants
from alerting.messageprocessor import message_processor

logger = helpers.initialize_logger()


class ZKNodeCountMessageProcessor(message_processor.MessageProcessor):
    def __init__(self, platform, env_cluster, namespace) -> None:
        self.platform = platform
        self.env_cluster = env_cluster
        self.namespace = namespace

    def form_alert_message(self, message) -> str:
        zk_count_list = self.process_message(message)
        environment = helpers.get_message_property(message, 'environment')
        platform = 'DPAS' if self.platform == 'dpas' else 'OnePulse'
        message_attachment_list = []
        if zk_count_list:
            attachment_fields = [{"title": "Pod Name", "short": json.dumps(True)},
                                 {"title": "ZK Node Count",
                                  "short": json.dumps(True)}]
            for zk_count in zk_count_list:
                attachment_fields.append({"value": zk_count['zk_pod_name'], "short": json.dumps(True)})
                attachment_fields.append({"value": zk_count['zknode_count'], "short": json.dumps(True)})

            message_attachment_list = [{"fields": attachment_fields,  "color": constants.report_color_code,
                                        "title": f"ZK Node Count in {platform} {environment} {self.env_cluster} environment"}]

        if message_attachment_list:
            alert_message = json.dumps({"attachments": message_attachment_list})
            return alert_message

    def process_message(self, message) -> Any:
        logger.info("Processing zknode count alert message")
        try:
            data_set = message['data_set']
            zknode_count_data = data_set[next(iter(data_set))]
            return zknode_count_data

        except Exception as e:
            logger.error("Error while extracting zknode count alert messages data set :: %s" % e)