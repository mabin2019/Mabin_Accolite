from typing import Any
import json
from os import path
from alerting.util import helpers, constants
from alerting.messageprocessor import message_processor

logger = helpers.initialize_logger()


class ProcessStatusMessageProcessor(message_processor.MessageProcessor):
    def __init__(self, platform, env_cluster, namespace) -> None:
        self.platform = platform
        self.env_cluster = env_cluster
        self.namespace = namespace

    def form_alert_message(self, message) -> str:
        environment = helpers.get_message_property(message, 'environment')
        alert_type = helpers.get_message_property(message, 'type')
        process_type = alert_type.split('-')[0]
        platform = 'DPAS' if self.platform == 'dpas' else 'OnePulse'

        logger.info("Reading latest alert message for type %s" % alert_type)
        latest_alert_message = {}
        alert_message_file_path = '/tmp/' + alert_type + '.json'
        if path.isfile(alert_message_file_path):
            with open(alert_message_file_path) as latest_alert_message_file:
                latest_alert_message = json.load(latest_alert_message_file)

        if message['data_set'] == 'Error while executing jobdeployer command':
            message_attachment_list = [{"color": constants.failure_color_code,
                                        "title": f"ALERT! Error while executing jobdeployer command in {platform} {environment} {self.env_cluster} environment"}]

            return json.dumps({"attachments": message_attachment_list})

        message_attachment_list = []
        not_running_process_list = self.process_message(message, process_type)

        if not_running_process_list:
            attachment_fields = [{"title": f"List of {process_type} not running"
                                  }]
            for process_name in not_running_process_list:
                attachment_fields.append({"value": process_name})

            message_attachment_list = [{"fields": attachment_fields, "color": constants.failure_color_code,
                                        "title": f"ALERT! {process_type.capitalize()} down in {platform} {environment} {self.env_cluster} environment"}]


        else:
            if bool(latest_alert_message) and bool(latest_alert_message['data_set']):
                message_attachment_list = [{"color": constants.success_color_code,
                                            "title": f"All {process_type} are running in {platform} {environment} {self.env_cluster} environment"}]

        if message_attachment_list:
            alert_message = json.dumps({"attachments": message_attachment_list})
            return alert_message

    def process_message(self, message, process_type) -> Any:
        logger.info("Processing process status alert message")
        try:
            data_set = message['data_set']
            if not bool(data_set):
                return None

            process_list = data_set['job_names'] if process_type == 'jobs' else data_set['pod_names']
            return process_list
        except Exception as e:
            logger.error("Error while extracting process status alert messages data set :: %s" % e)
