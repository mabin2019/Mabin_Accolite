CUR_PATH=`pwd`
while read i
 do
 sh ${CUR_PATH}/$i/get_operations.sh `grep $i ${CUR_PATH}/deployer_paths.txt | cut -d':' -f2`
 if [ `cat ${CUR_PATH}/$i/nr.txt | wc -l` -eq 0 ] && [ `cat ${CUR_PATH}/$i/no.txt | wc -l` -eq 0  ]
 then
        echo "0" > ${CUR_PATH}/$i/change.txt
 else
        echo "1" > ${CUR_PATH}/$i/change.txt
 fi
 done < ${CUR_PATH}/env.txt
if [ `cat ${CUR_PATH}/UAT-AZ2/change.txt` -eq 0 ] && [ `cat ${CUR_PATH}/UAT-AZ1/change.txt` -eq 0 ] && [ `cat ${CUR_PATH}/PROD-AZ2/change.txt` -eq 0 ] && [ `cat ${CUR_PATH}/PROD-AZ1/change.txt` -eq 0 ]
then
       exit
fi
echo "#!/usr/bin/perl

 \$to = 'pulse-support@accoliteindia.com';
 \$cc = 'Avi.Baraswal@pudential.com.sg';
 \$from = 'Jobs_ReportUser@prudential.com.sg';
 \$subject = 'One Pulse Environments Operations check';
 \$message = '<p>Hi All,<br>Please find below the operations check results.</p>
 <br>
 <table border=1 style=\"border-collapse: collapse;padding: 4px\">
 <tr><th>Environment</th><th>Missing Operations</th><th>New Operations</th></tr>" >${CUR_PATH}/mail.pl

while read i
 do
 echo "<tr align=\"center\"><td>`echo $i`</td><td><pre>" >>${CUR_PATH}/mail.pl
# if [ `comm -23 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt | wc -l` -eq 0 ]
# then
#        echo "All jobs are running</pre></td><td><pre>" >>${CUR_PATH}/mail.pl
# else
#        comm -23 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt > ${CUR_PATH}/$i/nr.txt
#        cat ${CUR_PATH}/$i/nr.txt >> ${CUR_PATH}/mail.pl
#        echo "</td><td><pre>" >> ${CUR_PATH}/mail.pl
# fi
if [ `cat ${CUR_PATH}/$i/nr.txt | wc -l` -ne 0 ]
then
 cat ${CUR_PATH}/$i/nr.txt >> ${CUR_PATH}/mail.pl
else
 echo "All Operations are running" >>${CUR_PATH}/mail.pl
fi
 echo "</td><td><pre>" >> ${CUR_PATH}/mail.pl
# if [ `comm -13 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt | wc -l` -eq 0 ]
# then
#        echo "No new jobs</pre></td><td></pre>" >>${CUR_PATH}/mail.pl
# else
#        echo "`comm -13 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt`" >> ${CUR_PATH}/mail.pl
#        echo "</pre></td><td><pre>" >> ${CUR_PATH}/mail.pl
#        if [[ "$1" == "ADD" ]]
#        then
#                cp ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/dummy
#                comm -13 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt >> ${CUR_PATH}/$i/dummy
#                cat ${CUR_PATH}/$i/dummy | sort > ${CUR_PATH}/$i/all_jobs.txt
#                rm -f  ${CUR_PATH}/$i/dummy
#        fi
# fi
if [ `cat ${CUR_PATH}/$i/no.txt | wc -l` -ne 0 ]
then
 cat ${CUR_PATH}/$i/no.txt  >> ${CUR_PATH}/mail.pl
else 
 echo "No new operations" >> ${CUR_PATH}/mail.pl
fi
 echo "</pre></td></tr>" >> ${CUR_PATH}/mail.pl
rm -f ${CUR_PATH}/$i/*.txt
rm -f ${CUR_PATH}/$i/OPERATION_LIST/*.txt
 done < ${CUR_PATH}/env.txt
 echo " </table><br>
 <p>**This is an auto-generated mail on discrepancy in Jobs running.<br><br>Regards,<br>Triage-Team</p/>';

  open(MAIL, \"|/usr/sbin/sendmail -t\");

   # Email Header
   print MAIL \"To: \$to\\n\";
   print MAIL \"Cc: \$cc\\n\";
   print MAIL \"From: \$from\\n\";
   print MAIL \"Subject: \$subject\\n\";
   print MAIL \"Content-Type: text/html\\n\";

   # Email Body
   print MAIL \$message;

   close(MAIL);
  " >>${CUR_PATH}/mail.pl
chmod 755 ${CUR_PATH}/mail.pl
perl ${CUR_PATH}/mail.pl
rm -f  ${CUR_PATH}/mail.pl
