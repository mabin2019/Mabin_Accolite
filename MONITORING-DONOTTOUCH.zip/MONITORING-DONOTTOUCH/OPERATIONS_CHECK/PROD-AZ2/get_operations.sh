CUR_PATH=/home/346771/MONITORING-DONOTTOUCH/OPERATIONS_CHECK/PROD-AZ2
if [ $# -ne 1 ]
then
        echo "Please enter the absolute path for deployer token as argument. Exiting.."
        exit
fi
kubectl --kubeconfig $1 exec flink-jm-0 -- bash -c "jobdeployer list" > ${CUR_PATH}/master.txt
cat ${CUR_PATH}/master.txt |grep '(' | cut -d':' -f5|cut -d'(' -f1 | sort | tr -d " " > ${CUR_PATH}/fetch.txt
for i in `cat ${CUR_PATH}/fetch.txt`
do
        cat ${CUR_PATH}/master.txt | grep $i -w | rev | cut -d':' -f1 | rev | sed 's/,/\n/g' | sort > ${CUR_PATH}/OPERATION_LIST/$i.txt
done
#find ${CUR_PATH}/OPERATION_LIST/ -size 1 | xargs rm -f
ls ${CUR_PATH}/ALL_LIST | sort > ${CUR_PATH}/all_jobs.txt
ls ${CUR_PATH}/OPERATION_LIST > ${CUR_PATH}/fetch_jobs.txt
comm -23 ${CUR_PATH}/all_jobs.txt ${CUR_PATH}/fetch_jobs.txt > ${CUR_PATH}/nr_jobs.txt
for i in `cat ${CUR_PATH}/nr_jobs.txt`
do
	job_name=`echo $i | cut -d'.' -f1`
	echo "${job_name}:" >> ${CUR_PATH}/nr.txt
	 cat ${CUR_PATH}/ALL_LIST/$i >> ${CUR_PATH}/nr.txt
done
for i in `ls ${CUR_PATH}/OPERATION_LIST`
do
	job_name=`echo $i | cut -d'.' -f1`
	#echo "Checking for job - ${job_name}"
	if [ -f ${CUR_PATH}/ALL_LIST/$i ]
	then
	if [ `comm -23 ${CUR_PATH}/ALL_LIST/$i ${CUR_PATH}/OPERATION_LIST/$i | wc -l` -ne 0 ]
	then
		echo "${job_name}:" >> ${CUR_PATH}/nr.txt
		comm -23 ${CUR_PATH}/ALL_LIST/$i ${CUR_PATH}/OPERATION_LIST/$i >> ${CUR_PATH}/nr.txt
	fi
	if [ `comm -13 ${CUR_PATH}/ALL_LIST/$i ${CUR_PATH}/OPERATION_LIST/$i | wc -l` -ne 0 ]
	then
		echo "${job_name}:" >>  ${CUR_PATH}/no.txt
		comm -13 ${CUR_PATH}/ALL_LIST/$i ${CUR_PATH}/OPERATION_LIST/$i >> ${CUR_PATH}/no.txt
	fi
	else
		echo -e "$job_name:" >> ${CUR_PATH}/no.txt
		cat ${CUR_PATH}/OPERATION_LIST/$i >> ${CUR_PATH}/no.txt		
	fi
done
