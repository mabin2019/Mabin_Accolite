grep "Invalid Operation" /opt/flink/log/application-2021-03* | wc -l
grep "Invalid Operation" /opt/flink/log/application-2021-02* | wc -l
grep "Invalid Operation" /opt/flink/log/application.log | wc -l
