#!/bin/sh
if [ $# -ne 1 ]
then
	echo "Please enter deployer token with absolute path as argument. Exitting...."
	exit
fi
if [ `kubectl --kubeconfig $1 get pods | grep 'flink-tm' | awk '{print $1}' | wc -l` -eq 0 ]
then
	echo "The deployer token entered is not proper. Please check again."
	exit
fi
>log.txt
for i in `kubectl --kubeconfig $1 get pods | grep 'flink-tm-' | awk '{print $1}' `
do
	echo "-----------------------------------------"
	echo "Applying the credential change in $i pod"
	kubectl --kubeconfig $1 cp /home/346771/MONITORING-DONOTTOUCH/CREDENTIAL/websocket.sh $i:/tmp
	kubectl --kubeconfig $1 exec -it $i -- bash -c "sh /tmp/websocket.sh" >> log.txt
	echo "-----------------------------------------"
done
