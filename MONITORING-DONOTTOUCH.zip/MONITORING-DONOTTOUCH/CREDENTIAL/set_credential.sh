#!/bin/sh
cp /etc/secrets/credential /etc/secrets/credentials.sh
chmod 777 /etc/secrets/credentials.sh
# removing extra spaces and creating export environment variable format
sed -ie 's/\:\ /\=/g' /etc/secrets/credentials.sh
#sed -ie 's/BEGIN PRIVATE KEY/BEGIN_PRIVATE_KEY/g' /etc/secrets/credentials.sh
#sed -ie 's/END PRIVATE KEY/END_PRIVATE_KEY/g' /etc/secrets/credentials.sh
sed -ie 's/ /\n/g' /etc/secrets/credentials.sh
sed -i '$ d' /etc/secrets/credentials.sh
sed -ie 's/^/export /' /etc/secrets/credentials.sh

#sed -ie 's/BEGIN_PRIVATE_KEY/BEGIN PRIVATE KEY/g' /etc/secrets/credentials.sh
#sed -ie 's/END_PRIVATE_KEY/END PRIVATE KEY/g' /etc/secrets/credentials.sh
. /etc/secrets/credentials.sh

# removing this file again
rm -f /etc/secrets/credentials.sh
