#!/bin/sh
CUR_PATH=`pwd`
>${CUR_PATH}/out.txt
if [ $# -ne 2 ]
then
	echo "Please enter deployer token with absolute path as argument. Exitting...."
	exit
fi
if [ `kubectl --kubeconfig $1 get pods | grep 'flink-tm' | awk '{print $1}' | wc -l` -eq 0 ]
then
	echo "The deployer token entered is not proper. Please check again."
	exit
fi
for i in `kubectl --kubeconfig $1 get pods | grep 'kafka-' | awk '{print $1}' `
do
	old=`cat $i.txt`
	kubectl --kubeconfig $1 exec -it $i -- bash -c "df -h /kafka |  grep kafka" > $CUR_PATH/$i.txt
	new=`cat $CUR_PATH/$i.txt | awk '{print $5}'|tr -d "%"`
	diff=$((new-old)) 
	echo $new > $i.txt
	echo "$i $new $diff" >>${CUR_PATH}/out.txt
	dos2unix ${CUR_PATH}/out.txt
done
if [ `cat ${CUR_PATH}/out.txt | wc -l` -ne 0 ]
then
	sh ${CUR_PATH}/generate_mail.sh $2
fi
#rm -f ${CUR_PATH}/*.txt
