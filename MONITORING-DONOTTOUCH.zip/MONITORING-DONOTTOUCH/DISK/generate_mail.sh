CUR_PATH=/home/346771/MONITORING-DONOTTOUCH/DISK
echo "#!/usr/bin/perl

 \$to = 'pulse-support@accoliteindia.com';
 \$cc = 'veluru.yadav@prudential.com.sg';
 \$from = 'KafkaUsage_ReportUser@prudential.com.sg';
 \$subject = 'One Pulse Kafka Disk Usage';
 \$message = '<p>Hi All,<br>Please find below the current disk usage details from $1 .</p>
<br>
 <table border=1 style=\"border-collapse: collapse;padding: 4px\">
 <tr><th>Pod Name</th><th>Current Usage(%)</th><th>Increase(%)</th></tr>" >${CUR_PATH}/mail.pl

while read i
 do
 echo "<tr align=\"center\"><td>`echo $i | awk '{print $1}'`</td><td><pre>`echo $i | awk '{print $2}'`</td><td><pre>`echo $i | awk '{print $3}'`</td></tr>" >>${CUR_PATH}/mail.pl
 done < ${CUR_PATH}/out.txt
 echo " </table><br>
 <p>**This is an auto-generated mail.<br><br>Regards,<br>Triage-Team</p/>';

  open(MAIL, \"|/usr/sbin/sendmail -t\");

   # Email Header
   print MAIL \"To: \$to\\n\";
   print MAIL \"Cc: \$cc\\n\";
   print MAIL \"From: \$from\\n\";
   print MAIL \"Subject: \$subject\\n\";
   print MAIL \"Content-Type: text/html\\n\";

   # Email Body
   print MAIL \$message;

   close(MAIL);
  " >>${CUR_PATH}/mail.pl
chmod 755 ${CUR_PATH}/mail.pl
perl ${CUR_PATH}/mail.pl
rm -f  ${CUR_PATH}/mail.pl
