CUR_PATH=`pwd`
UATAZ1=`grep UATAZ1 ${CUR_PATH}/deployer_paths|cut -d':' -f2`
UATAZ2=`grep UATAZ2 ${CUR_PATH}/deployer_paths|cut -d':' -f2`
PRODAZ1=`grep PRODAZ1 ${CUR_PATH}/deployer_paths|cut -d':' -f2`
PRODAZ2=`grep PRODAZ2 ${CUR_PATH}/deployer_paths|cut -d':' -f2`

kubectl --kubeconfig $UATAZ1 get pods -o yaml | grep onepulse | grep 'image:' | grep -v ' - '|sort | uniq > UAT/UATAZ1.txt
kubectl --kubeconfig $UATAZ2 get pods -o yaml | grep onepulse | grep 'image:' | grep -v ' - '|sort | uniq > UAT/UATAZ2.txt
kubectl --kubeconfig $PRODAZ1 get pods -o yaml | grep onepulse | grep 'image:' | grep -v ' - '|sort | uniq > PROD/PRODAZ1.txt
kubectl --kubeconfig $PRODAZ2 get pods -o yaml | grep onepulse | grep 'image:' | grep -v ' - '|sort | uniq > PROD/PRODAZ2.txt
sh ${CUR_PATH}/generate_mail.sh
