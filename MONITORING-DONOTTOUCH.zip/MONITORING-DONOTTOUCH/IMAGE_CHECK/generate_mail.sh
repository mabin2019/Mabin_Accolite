CUR_PATH=`pwd`
echo "#!/usr/bin/perl

 \$to = 'Partha.Sarathy.Baytha@prudential.com.sg,Ashishkumar.Joshi@prudential.com.sg,avinash.singh@prudential.com.sg,veluru.yadav@prudential.com.sg';
 \$from = 'ImageChecker_ReportUser@prudential.com.sg';
 \$subject = ' Docker Image check';
 \$message = '<p>Hi All,<br>Please find below the image check results.</p>
 <table border=1 style=\"border-collapse: collapse;padding: 4px\">
 <tr><th>Image Name</th><th>AZ1 Image</th><th>AZ2 Image</th></tr>" >${CUR_PATH}/mail.pl
check=0
while read env
 do
        sort ${CUR_PATH}/$env/${env}AZ1.txt > ${CUR_PATH}/AZ1.txt
        sort ${CUR_PATH}/$env/${env}AZ2.txt > ${CUR_PATH}/AZ2.txt
        c=`comm -13 ${CUR_PATH}/AZ1.txt ${CUR_PATH}/AZ2.txt|wc -l`
        if [ $c -ne 0 ]
        then
                check=$((check+1))
        fi
 done < ${CUR_PATH}/env.txt
if [ $check -eq 0 ]
then
        echo "No Image Difference on `date`" >>${CUR_PATH}/log.txt
        exit
fi
while read env
 do
 echo "<tr align=\"center\"><th colspan=3 style=\"background-color:#ADD8E6\">`echo $env`</th></tr>" >>${CUR_PATH}/mail.pl
 sed -i 's/image: docker-rt-interconnect.pruregistry.intranet.asia:8443\/onepulse\///g' ${CUR_PATH}/$env/*.txt
 sed -n '/:/p' ${CUR_PATH}/$env/${env}AZ1.txt | sed 's/ //g' > ${CUR_PATH}/AZ1.txt
 sed -n '/:/p' ${CUR_PATH}/$env/${env}AZ2.txt | sed 's/ //g' > ${CUR_PATH}/AZ2.txt
 comm -13 ${CUR_PATH}/AZ1.txt ${CUR_PATH}/AZ2.txt | rev | cut -d':' -f2 | cut -d'/' -f2 | rev > ${CUR_PATH}/diff.txt
 while read i
 do
        echo "<tr><td>`echo $i`</td>" >>${CUR_PATH}/mail.pl
        echo "<td>`grep -w $i ${CUR_PATH}/AZ1.txt | rev | cut -d':' -f1 | rev | cut -d'-' -f2 | tail -1`</td>"  >>${CUR_PATH}/mail.pl
        echo "<td>`grep -w $i ${CUR_PATH}/AZ2.txt | rev | cut -d':' -f1 | rev | cut -d'-' -f2 | tail -1`</td></tr>"  >>${CUR_PATH}/mail.pl
 done < ${CUR_PATH}/diff.txt
 done < ${CUR_PATH}/env.txt
 echo " </table>
 <p>**This is an auto-generated mail on discrepancy in Images<br>Regards,<br>Triage-Team</p/>';

  open(MAIL, \"|/usr/sbin/sendmail -t\");

   # Email Header
   print MAIL \"To: \$to\\n\";
   print MAIL \"Cc: \$cc\\n\";
   print MAIL \"From: \$from\\n\";
   print MAIL \"Subject: \$subject\\n\";
   print MAIL \"Content-Type: text/html\\n\";

   # Email Body
   print MAIL \$message;

   close(MAIL);
  " >>${CUR_PATH}/mail.pl
chmod 755 ${CUR_PATH}/mail.pl
perl ${CUR_PATH}/mail.pl
rm -f  ${CUR_PATH}/mail.pl
rm -f  ${CUR_PATH}/AZ1.txt
rm -f  ${CUR_PATH}/AZ2.txt
rm -f  ${CUR_PATH}/diff.txt
