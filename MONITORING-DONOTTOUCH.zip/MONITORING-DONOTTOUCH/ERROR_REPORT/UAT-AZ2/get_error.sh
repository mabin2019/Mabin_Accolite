CUR_PATH=/home/346771/MONITORING-DONOTTOUCH/ERROR_REPORT/UAT-AZ2
TOKEN=/home/346771/Prudential/OnePulseUATAZ2_New/OnePulse-UAT-AZ2-deployer
for i in `cat ${CUR_PATH}/pod.txt`
do
	kubectl --kubeconfig $TOKEN cp /home/346771/MONITORING-DONOTTOUCH/ERROR_REPORT/fetch_error.sh $i:/tmp
	kubectl --kubeconfig $TOKEN  exec $i -- bash -c "chmod 755  /tmp/fetch_error.sh;sh /tmp/fetch_error.sh"  > ${CUR_PATH}/output_$i.txt 
done
sh ${CUR_PATH}/generate_mail.sh
