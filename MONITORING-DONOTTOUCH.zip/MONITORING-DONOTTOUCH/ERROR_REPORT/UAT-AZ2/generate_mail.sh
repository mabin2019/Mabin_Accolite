CUR_PATH=/home/346771/MONITORING-DONOTTOUCH/ERROR_REPORT/UAT-AZ2
echo "#!/usr/bin/perl

 \$to = 'pulse-support@accoliteindia.com';
 \$cc = 'mabin.thomas@prudential.com.sg';
 \$from = 'OPUAT_ReportUser@prudential.com.sg';
 \$subject = 'OP UAT|Error Report';
 \$message = '<p>Hi All,<br>Please find below the errors from OP UAT -AZ2 server from `date -d "210 minutes ago" +%T | cut -d":" -f1-2` to `date -d "150 minutes ago" +%T | cut -d":" -f1-2` IST.</p>
 <br>
 <table border=1 style=\"border-collapse: collapse;padding: 2px\">
 <tr><th>Log Level</th><th>Class Name</th><th>Exception</th><th>#Alert</th><th>TM</th></tr>" >${CUR_PATH}/mail.pl
 for j in `ls output_*`
 do

 while read i
 do
	message=`echo $i | cut -d'-' -f1| rev |cut -d' ' -f2| rev`
	if [ $message == "ERROR" ] || [ $message == "WARN" ] 
	then
        echo "<tr><td>`echo $i | awk '{print $2}'`</td><td></td><td>`echo $i | cut -d'-' -f2| awk -v n=1 '{ for (i=n; i<=NF; i++) printf "%s%s", $i, (i<NF ? OFS : ORS)}' | tr -d "'"` </td><td>`echo $i | awk '{print $1}'`</td><td>`echo $j | cut -d'_' -f2 | cut -d'.' -f1`</td></tr>" >> ${CUR_PATH}/mail.pl
	else
        echo "<tr><td>`echo $i | awk '{print $2}'`</td><td>`echo $i | cut -d'-' -f1| rev |cut -d' ' -f2| rev`</td><td>`echo $i | cut -d'-' -f2| awk -v n=1 '{ for (i=n; i<=NF; i++) printf "%s%s", $i, (i<NF ? OFS : ORS)}' | tr -d "'"` </td><td>`echo $i | awk '{print $1}'`</td><td>`echo $j | cut -d'_' -f2 | cut -d'.' -f1`</td></tr>" >> ${CUR_PATH}/mail.pl
fi
 done < $CUR_PATH/$j
 done
 echo " </table><br>
 <p>Regards,<br>Triage-Team</p/>';

  open(MAIL, \"|/usr/sbin/sendmail -t\");

   # Email Header
   print MAIL \"To: \$to\\n\";
   print MAIL \"Cc: \$cc\\n\";
   print MAIL \"From: \$from\\n\";
   print MAIL \"Subject: \$subject\\n\";
   print MAIL \"Content-Type: text/html\\n\";

   # Email Body
   print MAIL \$message;

   close(MAIL);
  " >>${CUR_PATH}/mail.pl
chmod 755 ${CUR_PATH}/mail.pl
perl ${CUR_PATH}/mail.pl
#rm -f ${CUR_PATH}/mail.pl ${CUR_PATH}/output*.txt
