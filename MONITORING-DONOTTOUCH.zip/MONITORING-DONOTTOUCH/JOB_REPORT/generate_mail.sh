CUR_PATH=/home/346771/MONITORING-DONOTTOUCH/JOB_REPORT
while read i
 do
 sh ${CUR_PATH}/$i/get_jobs.sh
 if [ `comm -23 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt | wc -l` -eq 0 ]
 then
        echo "0" > ${CUR_PATH}/$i/change.txt
 else
        echo "1" > ${CUR_PATH}/$i/change.txt
 fi
 if [ `comm -13 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt | wc -l` -eq 0 ]
 then
        echo "0" > ${CUR_PATH}/$i/new.txt
 else
        echo "1" > ${CUR_PATH}/$i/new.txt
 fi
 done < ${CUR_PATH}/env.txt
#if [ `cat ${CUR_PATH}/UAT-AZ2/change.txt` -eq 0 ]
#then
#       exit
#fi
echo "#!/usr/bin/perl

 \$to = 'veluru.yadav@prudential.com.sg,mabin.thomas@prudential.com.sg,Avinash.Singh@prudential.com.sg,Partha.Sarathy.Baytha@prudential.com.sg,pulse-support@accoliteindia.com,Sesh.Sankar@prudential.com.sg,Rafi.Shaik@prudential.com.sg,Santhosh.Angada@prudential.com.sg,anwar.kamaal@accolitedigital.com';
 \$cc = 'Ashishkumar.Joshi@prudential.com.sg,Avi.Baraswal@prudential.com.sg,Nitish.Kumar@prudential.com.sg,Divya.Joshi@prudential.com.sg,Prashant.Sugandhi@prudential.com.sg,Nandhini.Sarathy@prudential.com.sg,aditya.saxena@prudential.com.sg,Sangamesh.Gugwad@wedopulse.co.in,Pradyuman.Singh@prudential.com.sg,Sajal.Gupta@prudential.com.sg';
 \$from = 'Jobs_ReportUser@prudential.com.sg';
 \$subject = 'One Pulse Environments Job check';
 \$message = '<p>Hi All,<br>Please find below the jobs check results.</p>
 <br>
 <table border=1 style=\"border-collapse: collapse;padding: 4px\">
 <tr><th>Environment</th><th>Jobs NOT Running</th><th>New Jobs</th></tr>" >${CUR_PATH}/mail.pl

while read i
 do
 echo "<tr align=\"center\"><td>`echo $i`</td><td><pre>" >>${CUR_PATH}/mail.pl
 if [ `comm -23 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt | wc -l` -eq 0 ]
 then
        echo "All jobs are running</pre></td><td><pre>" >>${CUR_PATH}/mail.pl
 else
        comm -23 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt > ${CUR_PATH}/$i/nr.txt
        cat ${CUR_PATH}/$i/nr.txt >> ${CUR_PATH}/mail.pl
        echo "</td><td><pre>" >> ${CUR_PATH}/mail.pl
 fi
 if [ `comm -13 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt | wc -l` -eq 0 ]
 then
        echo "No new jobs</pre></td></tr>" >>${CUR_PATH}/mail.pl
 else
        echo "`comm -13 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt`" >> ${CUR_PATH}/mail.pl
        echo "</pre></td></tr>" >> ${CUR_PATH}/mail.pl
        if [[ "$1" == "ADD" ]]
        then
                cp ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/dummy
                comm -13 ${CUR_PATH}/$i/all_jobs.txt ${CUR_PATH}/$i/fetch.txt >> ${CUR_PATH}/$i/dummy
                cat ${CUR_PATH}/$i/dummy | sort > ${CUR_PATH}/$i/all_jobs.txt
                rm -f  ${CUR_PATH}/$i/dummy
        fi
 fi
 #if [ `cat ${CUR_PATH}/$i/wij.txt | wc -l` -eq 0 ]
 #then
 #       echo "None</pre></td><td><pre>" >>${CUR_PATH}/mail.pl
 #else
 #       echo "`cat ${CUR_PATH}/$i/wij.txt`" >> ${CUR_PATH}/mail.pl
 #       echo "</pre></td><td><pre>" >> ${CUR_PATH}/mail.pl
 #fi
 #if [ `cat ${CUR_PATH}/$i/non.txt | wc -l` -eq 0 ]
 #then
 #       echo "None</pre></td></tr>" >>${CUR_PATH}/mail.pl
 #else
 #       echo "`cat ${CUR_PATH}/$i/non.txt`" >> ${CUR_PATH}/mail.pl
 #       echo "</pre></td></tr>" >> ${CUR_PATH}/mail.pl
 #fi
 done < ${CUR_PATH}/env.txt
 echo " </table><br>
 <p>**This is an auto-generated mail on discrepancy in Jobs running.<br><br>Regards,<br>Triage-Team</p/>';

  open(MAIL, \"|/usr/sbin/sendmail -t\");

   # Email Header
   print MAIL \"To: \$to\\n\";
   print MAIL \"Cc: \$cc\\n\";
   print MAIL \"From: \$from\\n\";
   print MAIL \"Subject: \$subject\\n\";
   print MAIL \"Content-Type: text/html\\n\";

   # Email Body
   print MAIL \$message;

   close(MAIL);
  " >>${CUR_PATH}/mail.pl
chmod 755 ${CUR_PATH}/mail.pl
perl ${CUR_PATH}/mail.pl
rm -f  ${CUR_PATH}/mail.pl
