CUR_PATH=/home/346771/MONITORING-DONOTTOUCH/JOB_REPORT/UAT-AZ1
kubectl --kubeconfig /home/346771/Prudential/OnePulseUATAZ1_New/OnePulseUATAZ1_xb0qxv_latest exec flink-jm-0 -- bash -c "flink list | grep pulse | cut -d'.' -f4- | cut -d' ' -f1" > ${CUR_PATH}/jobs.txt
kubectl --kubeconfig /home/346771/Prudential/OnePulseUATAZ1_New/OnePulseUATAZ1_xb0qxv_latest exec flink-jm-0 -- bash -c "jobdeployer list | grep RUNNING | grep '(' | cut -d':' -f5|cut -d'(' -f1" >> ${CUR_PATH}/jobs.txt
sort ${CUR_PATH}/jobs.txt | tr -d " " > ${CUR_PATH}/fetch.txt
kubectl --kubeconfig /home/346771/Prudential/OnePulseUATAZ1_New/OnePulseUATAZ1_xb0qxv_latest exec flink-jm-0 -- bash -c "jobdeployer list| grep -i workflow | grep '(' | cut -d':' -f5|cut -d'(' -f1" > ${CUR_PATH}/wij.txt
kubectl --kubeconfig /home/346771/Prudential/OnePulseUATAZ1_New/OnePulseUATAZ1_xb0qxv_latest exec flink-jm-0 -- bash -c "jobdeployer list| grep -v RUNNING | grep '(' | cut -d':' -f5|cut -d'(' -f1" > ${CUR_PATH}/non.txt
rm -f  ${CUR_PATH}/jobs.txt
